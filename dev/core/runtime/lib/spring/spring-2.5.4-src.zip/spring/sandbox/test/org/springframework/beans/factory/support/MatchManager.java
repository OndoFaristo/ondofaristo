package org.springframework.beans.factory.support;

/**
 * Created by IntelliJ IDEA.
 * User: stevend
 * Date: 23-feb-2006
 * Time: 18:24:26
 * To change this template use File | Settings | File Templates.
 */
public class MatchManager {
    public Match createMatch(Player player1, Player player2, long id) {
        throw new UnsupportedOperationException();
    }
}
