package org.springframework.beans.factory.support;

/**
 * Created by IntelliJ IDEA.
 * User: stevend
 * Date: 23-feb-2006
 * Time: 18:20:27
 * To change this template use File | Settings | File Templates.
 */
public class Player {
}
