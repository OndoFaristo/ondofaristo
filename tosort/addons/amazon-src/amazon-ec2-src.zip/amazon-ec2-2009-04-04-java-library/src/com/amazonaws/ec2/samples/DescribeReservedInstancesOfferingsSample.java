/******************************************************************************* 
 *  Copyright 2008 Amazon Technologies, Inc.
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  
 *  You may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at: http://aws.amazon.com/apache2.0
 *  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 *  specific language governing permissions and limitations under the License.
 * ***************************************************************************** 
 *    __  _    _  ___ 
 *   (  )( \/\/ )/ __)
 *   /__\ \    / \__ \
 *  (_)(_) \/\/  (___/
 * 
 *  Amazon EC2 Java Library
 *  API Version: 2009-04-04
 *  Generated: Sun May 17 14:47:07 PDT 2009 
 * 
 */



package com.amazonaws.ec2.samples;

import java.util.List;
import java.util.ArrayList;
import com.amazonaws.ec2.*;
import com.amazonaws.ec2.model.*;
import com.amazonaws.ec2.mock.AmazonEC2Mock;

/**
 *
 * Describe Reserved Instances Offerings  Samples
 *
 *
 */
public class DescribeReservedInstancesOfferingsSample {

    /**
     * Just add few required parameters, and try the service
     * Describe Reserved Instances Offerings functionality
     *
     * @param args unused
     */
    public static void main(String... args) {
        
        /************************************************************************
         * Access Key ID and Secret Acess Key ID, obtained from:
         * http://aws.amazon.com
         ***********************************************************************/
        String accessKeyId = "<Your Access Key ID>";
        String secretAccessKey = "<Your Secret Access Key>";

        /************************************************************************
         * Instantiate Http Client Implementation of Amazon EC2 
         ***********************************************************************/
        AmazonEC2 service = new AmazonEC2Client(accessKeyId, secretAccessKey);
        
        /************************************************************************
         * Uncomment to try advanced configuration options. Available options are:
         *
         *  - Signature Version
         *  - Proxy Host and Proxy Port
         *  - Service URL
         *  - User Agent String to be sent to Amazon EC2   service
         *
         ***********************************************************************/
        // AmazonEC2Config config = new AmazonEC2Config();
        // config.setSignatureVersion("0");
        // AmazonEC2 service = new AmazonEC2Client(accessKeyId, secretAccessKey, config);
 
        /************************************************************************
         * Uncomment to try out Mock Service that simulates Amazon EC2 
         * responses without calling Amazon EC2  service.
         *
         * Responses are loaded from local XML files. You can tweak XML files to
         * experiment with various outputs during development
         *
         * XML files available under com/amazonaws/ec2/mock tree
         *
         ***********************************************************************/
        // AmazonEC2 service = new AmazonEC2Mock();

        /************************************************************************
         * Setup request parameters and uncomment invoke to try out 
         * sample for Describe Reserved Instances Offerings 
         ***********************************************************************/
         DescribeReservedInstancesOfferingsRequest request = new DescribeReservedInstancesOfferingsRequest();
        
         // @TODO: set request parameters here

         // invokeDescribeReservedInstancesOfferings(service, request);

    }


                                                                                                                        
    /**
     * Describe Reserved Instances Offerings  request sample
     * The DescribeReservedInstancesOfferings operation describes Reserved
     * Instance offerings that are available for purchase. With Amazon EC2
     * Reserved Instances, you purchase the right to launch Amazon EC2 instances
     * for a period of time (without getting insufficient capacity errors) and
     * pay a lower usage rate for the actual time used.
     *   
     * @param service instance of AmazonEC2 service
     * @param request Action to invoke
     */
    public static void invokeDescribeReservedInstancesOfferings(AmazonEC2 service, DescribeReservedInstancesOfferingsRequest request) {
        try {
            
            DescribeReservedInstancesOfferingsResponse response = service.describeReservedInstancesOfferings(request);

            
            System.out.println ("DescribeReservedInstancesOfferings Action Response");
            System.out.println ("=============================================================================");
            System.out.println ();

            System.out.println("    DescribeReservedInstancesOfferingsResponse");
            System.out.println();
            if (response.isSetResponseMetadata()) {
                System.out.println("        ResponseMetadata");
                System.out.println();
                ResponseMetadata  responseMetadata = response.getResponseMetadata();
                if (responseMetadata.isSetRequestId()) {
                    System.out.println("            RequestId");
                    System.out.println();
                    System.out.println("                " + responseMetadata.getRequestId());
                    System.out.println();
                }
            } 
            if (response.isSetDescribeReservedInstancesOfferingsResult()) {
                System.out.println("        DescribeReservedInstancesOfferingsResult");
                System.out.println();
                DescribeReservedInstancesOfferingsResult  describeReservedInstancesOfferingsResult = response.getDescribeReservedInstancesOfferingsResult();
                java.util.List<ReservedInstancesOffering> reservedInstancesOfferingList = describeReservedInstancesOfferingsResult.getReservedInstancesOffering();
                for (ReservedInstancesOffering reservedInstancesOffering : reservedInstancesOfferingList) {
                    System.out.println("            ReservedInstancesOffering");
                    System.out.println();
                    if (reservedInstancesOffering.isSetReservedInstancesOfferingId()) {
                        System.out.println("                ReservedInstancesOfferingId");
                        System.out.println();
                        System.out.println("                    " + reservedInstancesOffering.getReservedInstancesOfferingId());
                        System.out.println();
                    }
                    if (reservedInstancesOffering.isSetInstanceType()) {
                        System.out.println("                InstanceType");
                        System.out.println();
                        System.out.println("                    " + reservedInstancesOffering.getInstanceType());
                        System.out.println();
                    }
                    if (reservedInstancesOffering.isSetAvailabilityZone()) {
                        System.out.println("                AvailabilityZone");
                        System.out.println();
                        System.out.println("                    " + reservedInstancesOffering.getAvailabilityZone());
                        System.out.println();
                    }
                    if (reservedInstancesOffering.isSetDuration()) {
                        System.out.println("                Duration");
                        System.out.println();
                        System.out.println("                    " + reservedInstancesOffering.getDuration());
                        System.out.println();
                    }
                    if (reservedInstancesOffering.isSetUsagePrice()) {
                        System.out.println("                UsagePrice");
                        System.out.println();
                        System.out.println("                    " + reservedInstancesOffering.getUsagePrice());
                        System.out.println();
                    }
                    if (reservedInstancesOffering.isSetFixedPrice()) {
                        System.out.println("                FixedPrice");
                        System.out.println();
                        System.out.println("                    " + reservedInstancesOffering.getFixedPrice());
                        System.out.println();
                    }
                    if (reservedInstancesOffering.isSetProductDescription()) {
                        System.out.println("                ProductDescription");
                        System.out.println();
                        System.out.println("                    " + reservedInstancesOffering.getProductDescription());
                        System.out.println();
                    }
                }
            } 
            System.out.println();

           
        } catch (AmazonEC2Exception ex) {
            
            System.out.println("Caught Exception: " + ex.getMessage());
            System.out.println("Response Status Code: " + ex.getStatusCode());
            System.out.println("Error Code: " + ex.getErrorCode());
            System.out.println("Error Type: " + ex.getErrorType());
            System.out.println("Request ID: " + ex.getRequestId());
            System.out.print("XML: " + ex.getXML());
        }
    }
                                                                            
}
