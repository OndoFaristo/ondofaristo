/******************************************************************************* 
 *  Copyright 2008 Amazon Technologies, Inc.
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  
 *  You may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at: http://aws.amazon.com/apache2.0
 *  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 *  specific language governing permissions and limitations under the License.
 * ***************************************************************************** 
 *    __  _    _  ___ 
 *   (  )( \/\/ )/ __)
 *   /__\ \    / \__ \
 *  (_)(_) \/\/  (___/
 * 
 *  Amazon EC2 Java Library
 *  API Version: 2009-04-04
 *  Generated: Sun May 17 14:47:07 PDT 2009 
 * 
 */



package com.amazonaws.ec2;

import com.amazonaws.ec2.model.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;


/**
 * The Amazon Elastic Compute Cloud (Amazon EC2) web service provides you with
 * the ability to execute your applications in Amazon's computing environment.
 * To use Amazon EC2 you simply:
 * 1. Create an Amazon Machine Image (AMI) containing all your software, including
 * your operating system and associated configuration settings, applications,
 * libraries, etc. Think of this as zipping up the contents of your hard drive. We
 * provide all the necessary tools to create and package your AMI.
 * 2. Upload this AMI to the Amazon S3 (Amazon Simple Storage Service) service. This
 * gives us reliable, secure access to your AMI.
 * 3. Register your AMI with Amazon EC2. This allows us to verify that your AMI has
 * been uploaded correctly and to allocate a unique identifier for it.
 * 4. Use this AMI ID and the Amazon EC2 web service APIs to run, monitor, and
 * terminate as many instances of this AMI as required.
 * You can also skip the first three steps and choose to launch an AMI that is
 * provided by Amazon or shared by another user.
 * While instances are running, you are billed for the computing and network
 * resources that they consume.
 * You can also skip the first three steps and choose to launch an AMI that is
 * provided by Amazon or shared by another user.
 * While instances are running, you are billed for the computing and network
 * resources that they consume.
 * 
 *
 */
public class AmazonEC2AsyncClient extends AmazonEC2Client implements AmazonEC2Async {

    private ExecutorService executor;

    /**
     * Client to make asynchronous calls to the service. Please note, you should
     * configure executor with same number of concurrent threads as number of
     * http connections specified in AmazonEC2Config. Default number of
     * max http connections is 100.
     *
     * @param awsAccessKeyId AWS Access Key Id
     * @param awsSecretAccessKey AWS Secret Key
     * @param config service configuration. Pass new AmazonEC2Config() if you
     * plan to use defaults
     *
     * @param executor Executor service to manage asynchronous calls.
     *
     */
    public AmazonEC2AsyncClient(String awsAccessKeyId, String awsSecretAccessKey,
            AmazonEC2Config config, ExecutorService executor) {
        super(awsAccessKeyId, awsSecretAccessKey, config);
        this.executor = executor;
    }

            

    /**
     * Non-blocking Allocate Address 
     * <p/>
     * Returns <code>future</code> pointer to AllocateAddressResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return AllocateAddressResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;AllocateAddressResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;AllocateAddressResponse&gt;&gt;();
     *  for (AllocateAddressRequest request : requests) {
     *      responses.add(client.allocateAddressAsync(request));
     *  }
     *  for (Future&lt;AllocateAddressResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          AllocateAddressResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          AllocateAddressRequest request
     * @return Future&lt;AllocateAddressResponse&gt; future pointer to AllocateAddressResponse
     * 
     */
    public Future<AllocateAddressResponse> allocateAddressAsync(final AllocateAddressRequest request) {
        Future<AllocateAddressResponse> response = executor.submit(new Callable<AllocateAddressResponse>() {

            public AllocateAddressResponse call() throws AmazonEC2Exception {
                return allocateAddress(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Associate Address 
     * <p/>
     * Returns <code>future</code> pointer to AssociateAddressResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return AssociateAddressResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;AssociateAddressResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;AssociateAddressResponse&gt;&gt;();
     *  for (AssociateAddressRequest request : requests) {
     *      responses.add(client.associateAddressAsync(request));
     *  }
     *  for (Future&lt;AssociateAddressResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          AssociateAddressResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          AssociateAddressRequest request
     * @return Future&lt;AssociateAddressResponse&gt; future pointer to AssociateAddressResponse
     * 
     */
    public Future<AssociateAddressResponse> associateAddressAsync(final AssociateAddressRequest request) {
        Future<AssociateAddressResponse> response = executor.submit(new Callable<AssociateAddressResponse>() {

            public AssociateAddressResponse call() throws AmazonEC2Exception {
                return associateAddress(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Attach Volume 
     * <p/>
     * Returns <code>future</code> pointer to AttachVolumeResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return AttachVolumeResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;AttachVolumeResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;AttachVolumeResponse&gt;&gt;();
     *  for (AttachVolumeRequest request : requests) {
     *      responses.add(client.attachVolumeAsync(request));
     *  }
     *  for (Future&lt;AttachVolumeResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          AttachVolumeResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          AttachVolumeRequest request
     * @return Future&lt;AttachVolumeResponse&gt; future pointer to AttachVolumeResponse
     * 
     */
    public Future<AttachVolumeResponse> attachVolumeAsync(final AttachVolumeRequest request) {
        Future<AttachVolumeResponse> response = executor.submit(new Callable<AttachVolumeResponse>() {

            public AttachVolumeResponse call() throws AmazonEC2Exception {
                return attachVolume(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Authorize Security Group Ingress 
     * <p/>
     * Returns <code>future</code> pointer to AuthorizeSecurityGroupIngressResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return AuthorizeSecurityGroupIngressResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;AuthorizeSecurityGroupIngressResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;AuthorizeSecurityGroupIngressResponse&gt;&gt;();
     *  for (AuthorizeSecurityGroupIngressRequest request : requests) {
     *      responses.add(client.authorizeSecurityGroupIngressAsync(request));
     *  }
     *  for (Future&lt;AuthorizeSecurityGroupIngressResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          AuthorizeSecurityGroupIngressResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          AuthorizeSecurityGroupIngressRequest request
     * @return Future&lt;AuthorizeSecurityGroupIngressResponse&gt; future pointer to AuthorizeSecurityGroupIngressResponse
     * 
     */
    public Future<AuthorizeSecurityGroupIngressResponse> authorizeSecurityGroupIngressAsync(final AuthorizeSecurityGroupIngressRequest request) {
        Future<AuthorizeSecurityGroupIngressResponse> response = executor.submit(new Callable<AuthorizeSecurityGroupIngressResponse>() {

            public AuthorizeSecurityGroupIngressResponse call() throws AmazonEC2Exception {
                return authorizeSecurityGroupIngress(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Bundle Instance 
     * <p/>
     * Returns <code>future</code> pointer to BundleInstanceResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return BundleInstanceResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;BundleInstanceResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;BundleInstanceResponse&gt;&gt;();
     *  for (BundleInstanceRequest request : requests) {
     *      responses.add(client.bundleInstanceAsync(request));
     *  }
     *  for (Future&lt;BundleInstanceResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          BundleInstanceResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          BundleInstanceRequest request
     * @return Future&lt;BundleInstanceResponse&gt; future pointer to BundleInstanceResponse
     * 
     */
    public Future<BundleInstanceResponse> bundleInstanceAsync(final BundleInstanceRequest request) {
        Future<BundleInstanceResponse> response = executor.submit(new Callable<BundleInstanceResponse>() {

            public BundleInstanceResponse call() throws AmazonEC2Exception {
                return bundleInstance(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Cancel Bundle Task 
     * <p/>
     * Returns <code>future</code> pointer to CancelBundleTaskResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return CancelBundleTaskResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;CancelBundleTaskResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;CancelBundleTaskResponse&gt;&gt;();
     *  for (CancelBundleTaskRequest request : requests) {
     *      responses.add(client.cancelBundleTaskAsync(request));
     *  }
     *  for (Future&lt;CancelBundleTaskResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          CancelBundleTaskResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          CancelBundleTaskRequest request
     * @return Future&lt;CancelBundleTaskResponse&gt; future pointer to CancelBundleTaskResponse
     * 
     */
    public Future<CancelBundleTaskResponse> cancelBundleTaskAsync(final CancelBundleTaskRequest request) {
        Future<CancelBundleTaskResponse> response = executor.submit(new Callable<CancelBundleTaskResponse>() {

            public CancelBundleTaskResponse call() throws AmazonEC2Exception {
                return cancelBundleTask(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Confirm Product Instance 
     * <p/>
     * Returns <code>future</code> pointer to ConfirmProductInstanceResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return ConfirmProductInstanceResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;ConfirmProductInstanceResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;ConfirmProductInstanceResponse&gt;&gt;();
     *  for (ConfirmProductInstanceRequest request : requests) {
     *      responses.add(client.confirmProductInstanceAsync(request));
     *  }
     *  for (Future&lt;ConfirmProductInstanceResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          ConfirmProductInstanceResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          ConfirmProductInstanceRequest request
     * @return Future&lt;ConfirmProductInstanceResponse&gt; future pointer to ConfirmProductInstanceResponse
     * 
     */
    public Future<ConfirmProductInstanceResponse> confirmProductInstanceAsync(final ConfirmProductInstanceRequest request) {
        Future<ConfirmProductInstanceResponse> response = executor.submit(new Callable<ConfirmProductInstanceResponse>() {

            public ConfirmProductInstanceResponse call() throws AmazonEC2Exception {
                return confirmProductInstance(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Create Key Pair 
     * <p/>
     * Returns <code>future</code> pointer to CreateKeyPairResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return CreateKeyPairResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;CreateKeyPairResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;CreateKeyPairResponse&gt;&gt;();
     *  for (CreateKeyPairRequest request : requests) {
     *      responses.add(client.createKeyPairAsync(request));
     *  }
     *  for (Future&lt;CreateKeyPairResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          CreateKeyPairResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          CreateKeyPairRequest request
     * @return Future&lt;CreateKeyPairResponse&gt; future pointer to CreateKeyPairResponse
     * 
     */
    public Future<CreateKeyPairResponse> createKeyPairAsync(final CreateKeyPairRequest request) {
        Future<CreateKeyPairResponse> response = executor.submit(new Callable<CreateKeyPairResponse>() {

            public CreateKeyPairResponse call() throws AmazonEC2Exception {
                return createKeyPair(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Create Security Group 
     * <p/>
     * Returns <code>future</code> pointer to CreateSecurityGroupResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return CreateSecurityGroupResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;CreateSecurityGroupResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;CreateSecurityGroupResponse&gt;&gt;();
     *  for (CreateSecurityGroupRequest request : requests) {
     *      responses.add(client.createSecurityGroupAsync(request));
     *  }
     *  for (Future&lt;CreateSecurityGroupResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          CreateSecurityGroupResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          CreateSecurityGroupRequest request
     * @return Future&lt;CreateSecurityGroupResponse&gt; future pointer to CreateSecurityGroupResponse
     * 
     */
    public Future<CreateSecurityGroupResponse> createSecurityGroupAsync(final CreateSecurityGroupRequest request) {
        Future<CreateSecurityGroupResponse> response = executor.submit(new Callable<CreateSecurityGroupResponse>() {

            public CreateSecurityGroupResponse call() throws AmazonEC2Exception {
                return createSecurityGroup(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Create Snapshot 
     * <p/>
     * Returns <code>future</code> pointer to CreateSnapshotResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return CreateSnapshotResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;CreateSnapshotResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;CreateSnapshotResponse&gt;&gt;();
     *  for (CreateSnapshotRequest request : requests) {
     *      responses.add(client.createSnapshotAsync(request));
     *  }
     *  for (Future&lt;CreateSnapshotResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          CreateSnapshotResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          CreateSnapshotRequest request
     * @return Future&lt;CreateSnapshotResponse&gt; future pointer to CreateSnapshotResponse
     * 
     */
    public Future<CreateSnapshotResponse> createSnapshotAsync(final CreateSnapshotRequest request) {
        Future<CreateSnapshotResponse> response = executor.submit(new Callable<CreateSnapshotResponse>() {

            public CreateSnapshotResponse call() throws AmazonEC2Exception {
                return createSnapshot(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Create Volume 
     * <p/>
     * Returns <code>future</code> pointer to CreateVolumeResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return CreateVolumeResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;CreateVolumeResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;CreateVolumeResponse&gt;&gt;();
     *  for (CreateVolumeRequest request : requests) {
     *      responses.add(client.createVolumeAsync(request));
     *  }
     *  for (Future&lt;CreateVolumeResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          CreateVolumeResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          CreateVolumeRequest request
     * @return Future&lt;CreateVolumeResponse&gt; future pointer to CreateVolumeResponse
     * 
     */
    public Future<CreateVolumeResponse> createVolumeAsync(final CreateVolumeRequest request) {
        Future<CreateVolumeResponse> response = executor.submit(new Callable<CreateVolumeResponse>() {

            public CreateVolumeResponse call() throws AmazonEC2Exception {
                return createVolume(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Delete Key Pair 
     * <p/>
     * Returns <code>future</code> pointer to DeleteKeyPairResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DeleteKeyPairResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DeleteKeyPairResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DeleteKeyPairResponse&gt;&gt;();
     *  for (DeleteKeyPairRequest request : requests) {
     *      responses.add(client.deleteKeyPairAsync(request));
     *  }
     *  for (Future&lt;DeleteKeyPairResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DeleteKeyPairResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DeleteKeyPairRequest request
     * @return Future&lt;DeleteKeyPairResponse&gt; future pointer to DeleteKeyPairResponse
     * 
     */
    public Future<DeleteKeyPairResponse> deleteKeyPairAsync(final DeleteKeyPairRequest request) {
        Future<DeleteKeyPairResponse> response = executor.submit(new Callable<DeleteKeyPairResponse>() {

            public DeleteKeyPairResponse call() throws AmazonEC2Exception {
                return deleteKeyPair(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Delete Security Group 
     * <p/>
     * Returns <code>future</code> pointer to DeleteSecurityGroupResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DeleteSecurityGroupResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DeleteSecurityGroupResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DeleteSecurityGroupResponse&gt;&gt;();
     *  for (DeleteSecurityGroupRequest request : requests) {
     *      responses.add(client.deleteSecurityGroupAsync(request));
     *  }
     *  for (Future&lt;DeleteSecurityGroupResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DeleteSecurityGroupResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DeleteSecurityGroupRequest request
     * @return Future&lt;DeleteSecurityGroupResponse&gt; future pointer to DeleteSecurityGroupResponse
     * 
     */
    public Future<DeleteSecurityGroupResponse> deleteSecurityGroupAsync(final DeleteSecurityGroupRequest request) {
        Future<DeleteSecurityGroupResponse> response = executor.submit(new Callable<DeleteSecurityGroupResponse>() {

            public DeleteSecurityGroupResponse call() throws AmazonEC2Exception {
                return deleteSecurityGroup(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Delete Snapshot 
     * <p/>
     * Returns <code>future</code> pointer to DeleteSnapshotResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DeleteSnapshotResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DeleteSnapshotResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DeleteSnapshotResponse&gt;&gt;();
     *  for (DeleteSnapshotRequest request : requests) {
     *      responses.add(client.deleteSnapshotAsync(request));
     *  }
     *  for (Future&lt;DeleteSnapshotResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DeleteSnapshotResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DeleteSnapshotRequest request
     * @return Future&lt;DeleteSnapshotResponse&gt; future pointer to DeleteSnapshotResponse
     * 
     */
    public Future<DeleteSnapshotResponse> deleteSnapshotAsync(final DeleteSnapshotRequest request) {
        Future<DeleteSnapshotResponse> response = executor.submit(new Callable<DeleteSnapshotResponse>() {

            public DeleteSnapshotResponse call() throws AmazonEC2Exception {
                return deleteSnapshot(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Delete Volume 
     * <p/>
     * Returns <code>future</code> pointer to DeleteVolumeResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DeleteVolumeResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DeleteVolumeResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DeleteVolumeResponse&gt;&gt;();
     *  for (DeleteVolumeRequest request : requests) {
     *      responses.add(client.deleteVolumeAsync(request));
     *  }
     *  for (Future&lt;DeleteVolumeResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DeleteVolumeResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DeleteVolumeRequest request
     * @return Future&lt;DeleteVolumeResponse&gt; future pointer to DeleteVolumeResponse
     * 
     */
    public Future<DeleteVolumeResponse> deleteVolumeAsync(final DeleteVolumeRequest request) {
        Future<DeleteVolumeResponse> response = executor.submit(new Callable<DeleteVolumeResponse>() {

            public DeleteVolumeResponse call() throws AmazonEC2Exception {
                return deleteVolume(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Deregister Image 
     * <p/>
     * Returns <code>future</code> pointer to DeregisterImageResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DeregisterImageResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DeregisterImageResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DeregisterImageResponse&gt;&gt;();
     *  for (DeregisterImageRequest request : requests) {
     *      responses.add(client.deregisterImageAsync(request));
     *  }
     *  for (Future&lt;DeregisterImageResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DeregisterImageResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DeregisterImageRequest request
     * @return Future&lt;DeregisterImageResponse&gt; future pointer to DeregisterImageResponse
     * 
     */
    public Future<DeregisterImageResponse> deregisterImageAsync(final DeregisterImageRequest request) {
        Future<DeregisterImageResponse> response = executor.submit(new Callable<DeregisterImageResponse>() {

            public DeregisterImageResponse call() throws AmazonEC2Exception {
                return deregisterImage(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Describe Addresses 
     * <p/>
     * Returns <code>future</code> pointer to DescribeAddressesResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DescribeAddressesResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DescribeAddressesResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DescribeAddressesResponse&gt;&gt;();
     *  for (DescribeAddressesRequest request : requests) {
     *      responses.add(client.describeAddressesAsync(request));
     *  }
     *  for (Future&lt;DescribeAddressesResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DescribeAddressesResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DescribeAddressesRequest request
     * @return Future&lt;DescribeAddressesResponse&gt; future pointer to DescribeAddressesResponse
     * 
     */
    public Future<DescribeAddressesResponse> describeAddressesAsync(final DescribeAddressesRequest request) {
        Future<DescribeAddressesResponse> response = executor.submit(new Callable<DescribeAddressesResponse>() {

            public DescribeAddressesResponse call() throws AmazonEC2Exception {
                return describeAddresses(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Describe Availability Zones 
     * <p/>
     * Returns <code>future</code> pointer to DescribeAvailabilityZonesResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DescribeAvailabilityZonesResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DescribeAvailabilityZonesResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DescribeAvailabilityZonesResponse&gt;&gt;();
     *  for (DescribeAvailabilityZonesRequest request : requests) {
     *      responses.add(client.describeAvailabilityZonesAsync(request));
     *  }
     *  for (Future&lt;DescribeAvailabilityZonesResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DescribeAvailabilityZonesResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DescribeAvailabilityZonesRequest request
     * @return Future&lt;DescribeAvailabilityZonesResponse&gt; future pointer to DescribeAvailabilityZonesResponse
     * 
     */
    public Future<DescribeAvailabilityZonesResponse> describeAvailabilityZonesAsync(final DescribeAvailabilityZonesRequest request) {
        Future<DescribeAvailabilityZonesResponse> response = executor.submit(new Callable<DescribeAvailabilityZonesResponse>() {

            public DescribeAvailabilityZonesResponse call() throws AmazonEC2Exception {
                return describeAvailabilityZones(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Describe Bundle Tasks 
     * <p/>
     * Returns <code>future</code> pointer to DescribeBundleTasksResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DescribeBundleTasksResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DescribeBundleTasksResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DescribeBundleTasksResponse&gt;&gt;();
     *  for (DescribeBundleTasksRequest request : requests) {
     *      responses.add(client.describeBundleTasksAsync(request));
     *  }
     *  for (Future&lt;DescribeBundleTasksResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DescribeBundleTasksResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DescribeBundleTasksRequest request
     * @return Future&lt;DescribeBundleTasksResponse&gt; future pointer to DescribeBundleTasksResponse
     * 
     */
    public Future<DescribeBundleTasksResponse> describeBundleTasksAsync(final DescribeBundleTasksRequest request) {
        Future<DescribeBundleTasksResponse> response = executor.submit(new Callable<DescribeBundleTasksResponse>() {

            public DescribeBundleTasksResponse call() throws AmazonEC2Exception {
                return describeBundleTasks(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Describe Image Attribute 
     * <p/>
     * Returns <code>future</code> pointer to DescribeImageAttributeResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DescribeImageAttributeResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DescribeImageAttributeResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DescribeImageAttributeResponse&gt;&gt;();
     *  for (DescribeImageAttributeRequest request : requests) {
     *      responses.add(client.describeImageAttributeAsync(request));
     *  }
     *  for (Future&lt;DescribeImageAttributeResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DescribeImageAttributeResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DescribeImageAttributeRequest request
     * @return Future&lt;DescribeImageAttributeResponse&gt; future pointer to DescribeImageAttributeResponse
     * 
     */
    public Future<DescribeImageAttributeResponse> describeImageAttributeAsync(final DescribeImageAttributeRequest request) {
        Future<DescribeImageAttributeResponse> response = executor.submit(new Callable<DescribeImageAttributeResponse>() {

            public DescribeImageAttributeResponse call() throws AmazonEC2Exception {
                return describeImageAttribute(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Describe Images 
     * <p/>
     * Returns <code>future</code> pointer to DescribeImagesResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DescribeImagesResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DescribeImagesResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DescribeImagesResponse&gt;&gt;();
     *  for (DescribeImagesRequest request : requests) {
     *      responses.add(client.describeImagesAsync(request));
     *  }
     *  for (Future&lt;DescribeImagesResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DescribeImagesResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DescribeImagesRequest request
     * @return Future&lt;DescribeImagesResponse&gt; future pointer to DescribeImagesResponse
     * 
     */
    public Future<DescribeImagesResponse> describeImagesAsync(final DescribeImagesRequest request) {
        Future<DescribeImagesResponse> response = executor.submit(new Callable<DescribeImagesResponse>() {

            public DescribeImagesResponse call() throws AmazonEC2Exception {
                return describeImages(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Describe Instances 
     * <p/>
     * Returns <code>future</code> pointer to DescribeInstancesResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DescribeInstancesResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DescribeInstancesResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DescribeInstancesResponse&gt;&gt;();
     *  for (DescribeInstancesRequest request : requests) {
     *      responses.add(client.describeInstancesAsync(request));
     *  }
     *  for (Future&lt;DescribeInstancesResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DescribeInstancesResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DescribeInstancesRequest request
     * @return Future&lt;DescribeInstancesResponse&gt; future pointer to DescribeInstancesResponse
     * 
     */
    public Future<DescribeInstancesResponse> describeInstancesAsync(final DescribeInstancesRequest request) {
        Future<DescribeInstancesResponse> response = executor.submit(new Callable<DescribeInstancesResponse>() {

            public DescribeInstancesResponse call() throws AmazonEC2Exception {
                return describeInstances(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Describe Regions 
     * <p/>
     * Returns <code>future</code> pointer to DescribeRegionsResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DescribeRegionsResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DescribeRegionsResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DescribeRegionsResponse&gt;&gt;();
     *  for (DescribeRegionsRequest request : requests) {
     *      responses.add(client.describeRegionsAsync(request));
     *  }
     *  for (Future&lt;DescribeRegionsResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DescribeRegionsResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DescribeRegionsRequest request
     * @return Future&lt;DescribeRegionsResponse&gt; future pointer to DescribeRegionsResponse
     * 
     */
    public Future<DescribeRegionsResponse> describeRegionsAsync(final DescribeRegionsRequest request) {
        Future<DescribeRegionsResponse> response = executor.submit(new Callable<DescribeRegionsResponse>() {

            public DescribeRegionsResponse call() throws AmazonEC2Exception {
                return describeRegions(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Describe Reserved Instances 
     * <p/>
     * Returns <code>future</code> pointer to DescribeReservedInstancesResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DescribeReservedInstancesResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DescribeReservedInstancesResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DescribeReservedInstancesResponse&gt;&gt;();
     *  for (DescribeReservedInstancesRequest request : requests) {
     *      responses.add(client.describeReservedInstancesAsync(request));
     *  }
     *  for (Future&lt;DescribeReservedInstancesResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DescribeReservedInstancesResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DescribeReservedInstancesRequest request
     * @return Future&lt;DescribeReservedInstancesResponse&gt; future pointer to DescribeReservedInstancesResponse
     * 
     */
    public Future<DescribeReservedInstancesResponse> describeReservedInstancesAsync(final DescribeReservedInstancesRequest request) {
        Future<DescribeReservedInstancesResponse> response = executor.submit(new Callable<DescribeReservedInstancesResponse>() {

            public DescribeReservedInstancesResponse call() throws AmazonEC2Exception {
                return describeReservedInstances(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Describe Reserved Instances Offerings 
     * <p/>
     * Returns <code>future</code> pointer to DescribeReservedInstancesOfferingsResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DescribeReservedInstancesOfferingsResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DescribeReservedInstancesOfferingsResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DescribeReservedInstancesOfferingsResponse&gt;&gt;();
     *  for (DescribeReservedInstancesOfferingsRequest request : requests) {
     *      responses.add(client.describeReservedInstancesOfferingsAsync(request));
     *  }
     *  for (Future&lt;DescribeReservedInstancesOfferingsResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DescribeReservedInstancesOfferingsResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DescribeReservedInstancesOfferingsRequest request
     * @return Future&lt;DescribeReservedInstancesOfferingsResponse&gt; future pointer to DescribeReservedInstancesOfferingsResponse
     * 
     */
    public Future<DescribeReservedInstancesOfferingsResponse> describeReservedInstancesOfferingsAsync(final DescribeReservedInstancesOfferingsRequest request) {
        Future<DescribeReservedInstancesOfferingsResponse> response = executor.submit(new Callable<DescribeReservedInstancesOfferingsResponse>() {

            public DescribeReservedInstancesOfferingsResponse call() throws AmazonEC2Exception {
                return describeReservedInstancesOfferings(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Describe Key Pairs 
     * <p/>
     * Returns <code>future</code> pointer to DescribeKeyPairsResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DescribeKeyPairsResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DescribeKeyPairsResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DescribeKeyPairsResponse&gt;&gt;();
     *  for (DescribeKeyPairsRequest request : requests) {
     *      responses.add(client.describeKeyPairsAsync(request));
     *  }
     *  for (Future&lt;DescribeKeyPairsResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DescribeKeyPairsResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DescribeKeyPairsRequest request
     * @return Future&lt;DescribeKeyPairsResponse&gt; future pointer to DescribeKeyPairsResponse
     * 
     */
    public Future<DescribeKeyPairsResponse> describeKeyPairsAsync(final DescribeKeyPairsRequest request) {
        Future<DescribeKeyPairsResponse> response = executor.submit(new Callable<DescribeKeyPairsResponse>() {

            public DescribeKeyPairsResponse call() throws AmazonEC2Exception {
                return describeKeyPairs(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Describe Security Groups 
     * <p/>
     * Returns <code>future</code> pointer to DescribeSecurityGroupsResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DescribeSecurityGroupsResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DescribeSecurityGroupsResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DescribeSecurityGroupsResponse&gt;&gt;();
     *  for (DescribeSecurityGroupsRequest request : requests) {
     *      responses.add(client.describeSecurityGroupsAsync(request));
     *  }
     *  for (Future&lt;DescribeSecurityGroupsResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DescribeSecurityGroupsResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DescribeSecurityGroupsRequest request
     * @return Future&lt;DescribeSecurityGroupsResponse&gt; future pointer to DescribeSecurityGroupsResponse
     * 
     */
    public Future<DescribeSecurityGroupsResponse> describeSecurityGroupsAsync(final DescribeSecurityGroupsRequest request) {
        Future<DescribeSecurityGroupsResponse> response = executor.submit(new Callable<DescribeSecurityGroupsResponse>() {

            public DescribeSecurityGroupsResponse call() throws AmazonEC2Exception {
                return describeSecurityGroups(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Describe Snapshots 
     * <p/>
     * Returns <code>future</code> pointer to DescribeSnapshotsResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DescribeSnapshotsResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DescribeSnapshotsResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DescribeSnapshotsResponse&gt;&gt;();
     *  for (DescribeSnapshotsRequest request : requests) {
     *      responses.add(client.describeSnapshotsAsync(request));
     *  }
     *  for (Future&lt;DescribeSnapshotsResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DescribeSnapshotsResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DescribeSnapshotsRequest request
     * @return Future&lt;DescribeSnapshotsResponse&gt; future pointer to DescribeSnapshotsResponse
     * 
     */
    public Future<DescribeSnapshotsResponse> describeSnapshotsAsync(final DescribeSnapshotsRequest request) {
        Future<DescribeSnapshotsResponse> response = executor.submit(new Callable<DescribeSnapshotsResponse>() {

            public DescribeSnapshotsResponse call() throws AmazonEC2Exception {
                return describeSnapshots(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Describe Volumes 
     * <p/>
     * Returns <code>future</code> pointer to DescribeVolumesResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DescribeVolumesResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DescribeVolumesResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DescribeVolumesResponse&gt;&gt;();
     *  for (DescribeVolumesRequest request : requests) {
     *      responses.add(client.describeVolumesAsync(request));
     *  }
     *  for (Future&lt;DescribeVolumesResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DescribeVolumesResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DescribeVolumesRequest request
     * @return Future&lt;DescribeVolumesResponse&gt; future pointer to DescribeVolumesResponse
     * 
     */
    public Future<DescribeVolumesResponse> describeVolumesAsync(final DescribeVolumesRequest request) {
        Future<DescribeVolumesResponse> response = executor.submit(new Callable<DescribeVolumesResponse>() {

            public DescribeVolumesResponse call() throws AmazonEC2Exception {
                return describeVolumes(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Detach Volume 
     * <p/>
     * Returns <code>future</code> pointer to DetachVolumeResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DetachVolumeResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DetachVolumeResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DetachVolumeResponse&gt;&gt;();
     *  for (DetachVolumeRequest request : requests) {
     *      responses.add(client.detachVolumeAsync(request));
     *  }
     *  for (Future&lt;DetachVolumeResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DetachVolumeResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DetachVolumeRequest request
     * @return Future&lt;DetachVolumeResponse&gt; future pointer to DetachVolumeResponse
     * 
     */
    public Future<DetachVolumeResponse> detachVolumeAsync(final DetachVolumeRequest request) {
        Future<DetachVolumeResponse> response = executor.submit(new Callable<DetachVolumeResponse>() {

            public DetachVolumeResponse call() throws AmazonEC2Exception {
                return detachVolume(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Disassociate Address 
     * <p/>
     * Returns <code>future</code> pointer to DisassociateAddressResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return DisassociateAddressResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;DisassociateAddressResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;DisassociateAddressResponse&gt;&gt;();
     *  for (DisassociateAddressRequest request : requests) {
     *      responses.add(client.disassociateAddressAsync(request));
     *  }
     *  for (Future&lt;DisassociateAddressResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          DisassociateAddressResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          DisassociateAddressRequest request
     * @return Future&lt;DisassociateAddressResponse&gt; future pointer to DisassociateAddressResponse
     * 
     */
    public Future<DisassociateAddressResponse> disassociateAddressAsync(final DisassociateAddressRequest request) {
        Future<DisassociateAddressResponse> response = executor.submit(new Callable<DisassociateAddressResponse>() {

            public DisassociateAddressResponse call() throws AmazonEC2Exception {
                return disassociateAddress(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Get Console Output 
     * <p/>
     * Returns <code>future</code> pointer to GetConsoleOutputResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return GetConsoleOutputResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;GetConsoleOutputResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;GetConsoleOutputResponse&gt;&gt;();
     *  for (GetConsoleOutputRequest request : requests) {
     *      responses.add(client.getConsoleOutputAsync(request));
     *  }
     *  for (Future&lt;GetConsoleOutputResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          GetConsoleOutputResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          GetConsoleOutputRequest request
     * @return Future&lt;GetConsoleOutputResponse&gt; future pointer to GetConsoleOutputResponse
     * 
     */
    public Future<GetConsoleOutputResponse> getConsoleOutputAsync(final GetConsoleOutputRequest request) {
        Future<GetConsoleOutputResponse> response = executor.submit(new Callable<GetConsoleOutputResponse>() {

            public GetConsoleOutputResponse call() throws AmazonEC2Exception {
                return getConsoleOutput(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Modify Image Attribute 
     * <p/>
     * Returns <code>future</code> pointer to ModifyImageAttributeResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return ModifyImageAttributeResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;ModifyImageAttributeResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;ModifyImageAttributeResponse&gt;&gt;();
     *  for (ModifyImageAttributeRequest request : requests) {
     *      responses.add(client.modifyImageAttributeAsync(request));
     *  }
     *  for (Future&lt;ModifyImageAttributeResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          ModifyImageAttributeResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          ModifyImageAttributeRequest request
     * @return Future&lt;ModifyImageAttributeResponse&gt; future pointer to ModifyImageAttributeResponse
     * 
     */
    public Future<ModifyImageAttributeResponse> modifyImageAttributeAsync(final ModifyImageAttributeRequest request) {
        Future<ModifyImageAttributeResponse> response = executor.submit(new Callable<ModifyImageAttributeResponse>() {

            public ModifyImageAttributeResponse call() throws AmazonEC2Exception {
                return modifyImageAttribute(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Purchase Reserved Instances Offering 
     * <p/>
     * Returns <code>future</code> pointer to PurchaseReservedInstancesOfferingResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return PurchaseReservedInstancesOfferingResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;PurchaseReservedInstancesOfferingResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;PurchaseReservedInstancesOfferingResponse&gt;&gt;();
     *  for (PurchaseReservedInstancesOfferingRequest request : requests) {
     *      responses.add(client.purchaseReservedInstancesOfferingAsync(request));
     *  }
     *  for (Future&lt;PurchaseReservedInstancesOfferingResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          PurchaseReservedInstancesOfferingResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          PurchaseReservedInstancesOfferingRequest request
     * @return Future&lt;PurchaseReservedInstancesOfferingResponse&gt; future pointer to PurchaseReservedInstancesOfferingResponse
     * 
     */
    public Future<PurchaseReservedInstancesOfferingResponse> purchaseReservedInstancesOfferingAsync(final PurchaseReservedInstancesOfferingRequest request) {
        Future<PurchaseReservedInstancesOfferingResponse> response = executor.submit(new Callable<PurchaseReservedInstancesOfferingResponse>() {

            public PurchaseReservedInstancesOfferingResponse call() throws AmazonEC2Exception {
                return purchaseReservedInstancesOffering(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Reboot Instances 
     * <p/>
     * Returns <code>future</code> pointer to RebootInstancesResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return RebootInstancesResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;RebootInstancesResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;RebootInstancesResponse&gt;&gt;();
     *  for (RebootInstancesRequest request : requests) {
     *      responses.add(client.rebootInstancesAsync(request));
     *  }
     *  for (Future&lt;RebootInstancesResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          RebootInstancesResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          RebootInstancesRequest request
     * @return Future&lt;RebootInstancesResponse&gt; future pointer to RebootInstancesResponse
     * 
     */
    public Future<RebootInstancesResponse> rebootInstancesAsync(final RebootInstancesRequest request) {
        Future<RebootInstancesResponse> response = executor.submit(new Callable<RebootInstancesResponse>() {

            public RebootInstancesResponse call() throws AmazonEC2Exception {
                return rebootInstances(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Register Image 
     * <p/>
     * Returns <code>future</code> pointer to RegisterImageResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return RegisterImageResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;RegisterImageResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;RegisterImageResponse&gt;&gt;();
     *  for (RegisterImageRequest request : requests) {
     *      responses.add(client.registerImageAsync(request));
     *  }
     *  for (Future&lt;RegisterImageResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          RegisterImageResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          RegisterImageRequest request
     * @return Future&lt;RegisterImageResponse&gt; future pointer to RegisterImageResponse
     * 
     */
    public Future<RegisterImageResponse> registerImageAsync(final RegisterImageRequest request) {
        Future<RegisterImageResponse> response = executor.submit(new Callable<RegisterImageResponse>() {

            public RegisterImageResponse call() throws AmazonEC2Exception {
                return registerImage(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Release Address 
     * <p/>
     * Returns <code>future</code> pointer to ReleaseAddressResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return ReleaseAddressResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;ReleaseAddressResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;ReleaseAddressResponse&gt;&gt;();
     *  for (ReleaseAddressRequest request : requests) {
     *      responses.add(client.releaseAddressAsync(request));
     *  }
     *  for (Future&lt;ReleaseAddressResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          ReleaseAddressResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          ReleaseAddressRequest request
     * @return Future&lt;ReleaseAddressResponse&gt; future pointer to ReleaseAddressResponse
     * 
     */
    public Future<ReleaseAddressResponse> releaseAddressAsync(final ReleaseAddressRequest request) {
        Future<ReleaseAddressResponse> response = executor.submit(new Callable<ReleaseAddressResponse>() {

            public ReleaseAddressResponse call() throws AmazonEC2Exception {
                return releaseAddress(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Reset Image Attribute 
     * <p/>
     * Returns <code>future</code> pointer to ResetImageAttributeResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return ResetImageAttributeResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;ResetImageAttributeResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;ResetImageAttributeResponse&gt;&gt;();
     *  for (ResetImageAttributeRequest request : requests) {
     *      responses.add(client.resetImageAttributeAsync(request));
     *  }
     *  for (Future&lt;ResetImageAttributeResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          ResetImageAttributeResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          ResetImageAttributeRequest request
     * @return Future&lt;ResetImageAttributeResponse&gt; future pointer to ResetImageAttributeResponse
     * 
     */
    public Future<ResetImageAttributeResponse> resetImageAttributeAsync(final ResetImageAttributeRequest request) {
        Future<ResetImageAttributeResponse> response = executor.submit(new Callable<ResetImageAttributeResponse>() {

            public ResetImageAttributeResponse call() throws AmazonEC2Exception {
                return resetImageAttribute(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Revoke Security Group Ingress 
     * <p/>
     * Returns <code>future</code> pointer to RevokeSecurityGroupIngressResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return RevokeSecurityGroupIngressResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;RevokeSecurityGroupIngressResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;RevokeSecurityGroupIngressResponse&gt;&gt;();
     *  for (RevokeSecurityGroupIngressRequest request : requests) {
     *      responses.add(client.revokeSecurityGroupIngressAsync(request));
     *  }
     *  for (Future&lt;RevokeSecurityGroupIngressResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          RevokeSecurityGroupIngressResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          RevokeSecurityGroupIngressRequest request
     * @return Future&lt;RevokeSecurityGroupIngressResponse&gt; future pointer to RevokeSecurityGroupIngressResponse
     * 
     */
    public Future<RevokeSecurityGroupIngressResponse> revokeSecurityGroupIngressAsync(final RevokeSecurityGroupIngressRequest request) {
        Future<RevokeSecurityGroupIngressResponse> response = executor.submit(new Callable<RevokeSecurityGroupIngressResponse>() {

            public RevokeSecurityGroupIngressResponse call() throws AmazonEC2Exception {
                return revokeSecurityGroupIngress(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Run Instances 
     * <p/>
     * Returns <code>future</code> pointer to RunInstancesResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return RunInstancesResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;RunInstancesResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;RunInstancesResponse&gt;&gt;();
     *  for (RunInstancesRequest request : requests) {
     *      responses.add(client.runInstancesAsync(request));
     *  }
     *  for (Future&lt;RunInstancesResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          RunInstancesResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          RunInstancesRequest request
     * @return Future&lt;RunInstancesResponse&gt; future pointer to RunInstancesResponse
     * 
     */
    public Future<RunInstancesResponse> runInstancesAsync(final RunInstancesRequest request) {
        Future<RunInstancesResponse> response = executor.submit(new Callable<RunInstancesResponse>() {

            public RunInstancesResponse call() throws AmazonEC2Exception {
                return runInstances(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Terminate Instances 
     * <p/>
     * Returns <code>future</code> pointer to TerminateInstancesResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return TerminateInstancesResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;TerminateInstancesResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;TerminateInstancesResponse&gt;&gt;();
     *  for (TerminateInstancesRequest request : requests) {
     *      responses.add(client.terminateInstancesAsync(request));
     *  }
     *  for (Future&lt;TerminateInstancesResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          TerminateInstancesResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          TerminateInstancesRequest request
     * @return Future&lt;TerminateInstancesResponse&gt; future pointer to TerminateInstancesResponse
     * 
     */
    public Future<TerminateInstancesResponse> terminateInstancesAsync(final TerminateInstancesRequest request) {
        Future<TerminateInstancesResponse> response = executor.submit(new Callable<TerminateInstancesResponse>() {

            public TerminateInstancesResponse call() throws AmazonEC2Exception {
                return terminateInstances(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Monitor Instances 
     * <p/>
     * Returns <code>future</code> pointer to MonitorInstancesResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return MonitorInstancesResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;MonitorInstancesResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;MonitorInstancesResponse&gt;&gt;();
     *  for (MonitorInstancesRequest request : requests) {
     *      responses.add(client.monitorInstancesAsync(request));
     *  }
     *  for (Future&lt;MonitorInstancesResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          MonitorInstancesResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          MonitorInstancesRequest request
     * @return Future&lt;MonitorInstancesResponse&gt; future pointer to MonitorInstancesResponse
     * 
     */
    public Future<MonitorInstancesResponse> monitorInstancesAsync(final MonitorInstancesRequest request) {
        Future<MonitorInstancesResponse> response = executor.submit(new Callable<MonitorInstancesResponse>() {

            public MonitorInstancesResponse call() throws AmazonEC2Exception {
                return monitorInstances(request);
            }
        });
        return response;
    }


            

    /**
     * Non-blocking Unmonitor Instances 
     * <p/>
     * Returns <code>future</code> pointer to UnmonitorInstancesResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return UnmonitorInstancesResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonEC2Exception can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;UnmonitorInstancesResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;UnmonitorInstancesResponse&gt;&gt;();
     *  for (UnmonitorInstancesRequest request : requests) {
     *      responses.add(client.unmonitorInstancesAsync(request));
     *  }
     *  for (Future&lt;UnmonitorInstancesResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          UnmonitorInstancesResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonEC2Exception) {
     *              AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e);
     *          // handle AmazonEC2Exception
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          UnmonitorInstancesRequest request
     * @return Future&lt;UnmonitorInstancesResponse&gt; future pointer to UnmonitorInstancesResponse
     * 
     */
    public Future<UnmonitorInstancesResponse> unmonitorInstancesAsync(final UnmonitorInstancesRequest request) {
        Future<UnmonitorInstancesResponse> response = executor.submit(new Callable<UnmonitorInstancesResponse>() {

            public UnmonitorInstancesResponse call() throws AmazonEC2Exception {
                return unmonitorInstances(request);
            }
        });
        return response;
    }


}
