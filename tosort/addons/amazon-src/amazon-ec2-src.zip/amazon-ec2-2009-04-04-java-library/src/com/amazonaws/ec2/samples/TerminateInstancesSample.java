/******************************************************************************* 
 *  Copyright 2008 Amazon Technologies, Inc.
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  
 *  You may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at: http://aws.amazon.com/apache2.0
 *  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 *  specific language governing permissions and limitations under the License.
 * ***************************************************************************** 
 *    __  _    _  ___ 
 *   (  )( \/\/ )/ __)
 *   /__\ \    / \__ \
 *  (_)(_) \/\/  (___/
 * 
 *  Amazon EC2 Java Library
 *  API Version: 2009-04-04
 *  Generated: Sun May 17 14:47:07 PDT 2009 
 * 
 */



package com.amazonaws.ec2.samples;

import java.util.List;
import java.util.ArrayList;
import com.amazonaws.ec2.*;
import com.amazonaws.ec2.model.*;
import com.amazonaws.ec2.mock.AmazonEC2Mock;

/**
 *
 * Terminate Instances  Samples
 *
 *
 */
public class TerminateInstancesSample {

    /**
     * Just add few required parameters, and try the service
     * Terminate Instances functionality
     *
     * @param args unused
     */
    public static void main(String... args) {
        
        /************************************************************************
         * Access Key ID and Secret Acess Key ID, obtained from:
         * http://aws.amazon.com
         ***********************************************************************/
        String accessKeyId = "<Your Access Key ID>";
        String secretAccessKey = "<Your Secret Access Key>";

        /************************************************************************
         * Instantiate Http Client Implementation of Amazon EC2 
         ***********************************************************************/
        AmazonEC2 service = new AmazonEC2Client(accessKeyId, secretAccessKey);
        
        /************************************************************************
         * Uncomment to try advanced configuration options. Available options are:
         *
         *  - Signature Version
         *  - Proxy Host and Proxy Port
         *  - Service URL
         *  - User Agent String to be sent to Amazon EC2   service
         *
         ***********************************************************************/
        // AmazonEC2Config config = new AmazonEC2Config();
        // config.setSignatureVersion("0");
        // AmazonEC2 service = new AmazonEC2Client(accessKeyId, secretAccessKey, config);
 
        /************************************************************************
         * Uncomment to try out Mock Service that simulates Amazon EC2 
         * responses without calling Amazon EC2  service.
         *
         * Responses are loaded from local XML files. You can tweak XML files to
         * experiment with various outputs during development
         *
         * XML files available under com/amazonaws/ec2/mock tree
         *
         ***********************************************************************/
        // AmazonEC2 service = new AmazonEC2Mock();

        /************************************************************************
         * Setup request parameters and uncomment invoke to try out 
         * sample for Terminate Instances 
         ***********************************************************************/
         TerminateInstancesRequest request = new TerminateInstancesRequest();
        
         // @TODO: set request parameters here

         // invokeTerminateInstances(service, request);

    }


                                                                                                                                                                                        
    /**
     * Terminate Instances  request sample
     * The TerminateInstances operation shuts down one or more instances. This
     * operation is idempotent; if you terminate an instance more than once, each call
     * will succeed.
     * Terminated instances will remain visible after termination (approximately one
     * hour).
     *   
     * @param service instance of AmazonEC2 service
     * @param request Action to invoke
     */
    public static void invokeTerminateInstances(AmazonEC2 service, TerminateInstancesRequest request) {
        try {
            
            TerminateInstancesResponse response = service.terminateInstances(request);

            
            System.out.println ("TerminateInstances Action Response");
            System.out.println ("=============================================================================");
            System.out.println ();

            System.out.println("    TerminateInstancesResponse");
            System.out.println();
            if (response.isSetResponseMetadata()) {
                System.out.println("        ResponseMetadata");
                System.out.println();
                ResponseMetadata  responseMetadata = response.getResponseMetadata();
                if (responseMetadata.isSetRequestId()) {
                    System.out.println("            RequestId");
                    System.out.println();
                    System.out.println("                " + responseMetadata.getRequestId());
                    System.out.println();
                }
            } 
            if (response.isSetTerminateInstancesResult()) {
                System.out.println("        TerminateInstancesResult");
                System.out.println();
                TerminateInstancesResult  terminateInstancesResult = response.getTerminateInstancesResult();
                java.util.List<TerminatingInstance> terminatingInstanceList = terminateInstancesResult.getTerminatingInstance();
                for (TerminatingInstance terminatingInstance : terminatingInstanceList) {
                    System.out.println("            TerminatingInstance");
                    System.out.println();
                    if (terminatingInstance.isSetInstanceId()) {
                        System.out.println("                InstanceId");
                        System.out.println();
                        System.out.println("                    " + terminatingInstance.getInstanceId());
                        System.out.println();
                    }
                    if (terminatingInstance.isSetShutdownState()) {
                        System.out.println("                ShutdownState");
                        System.out.println();
                        InstanceState  shutdownState = terminatingInstance.getShutdownState();
                        if (shutdownState.isSetCode()) {
                            System.out.println("                    Code");
                            System.out.println();
                            System.out.println("                        " + shutdownState.getCode());
                            System.out.println();
                        }
                        if (shutdownState.isSetName()) {
                            System.out.println("                    Name");
                            System.out.println();
                            System.out.println("                        " + shutdownState.getName());
                            System.out.println();
                        }
                    } 
                    if (terminatingInstance.isSetPreviousState()) {
                        System.out.println("                PreviousState");
                        System.out.println();
                        InstanceState  previousState = terminatingInstance.getPreviousState();
                        if (previousState.isSetCode()) {
                            System.out.println("                    Code");
                            System.out.println();
                            System.out.println("                        " + previousState.getCode());
                            System.out.println();
                        }
                        if (previousState.isSetName()) {
                            System.out.println("                    Name");
                            System.out.println();
                            System.out.println("                        " + previousState.getName());
                            System.out.println();
                        }
                    } 
                }
            } 
            System.out.println();

           
        } catch (AmazonEC2Exception ex) {
            
            System.out.println("Caught Exception: " + ex.getMessage());
            System.out.println("Response Status Code: " + ex.getStatusCode());
            System.out.println("Error Code: " + ex.getErrorCode());
            System.out.println("Error Type: " + ex.getErrorType());
            System.out.println("Request ID: " + ex.getRequestId());
            System.out.print("XML: " + ex.getXML());
        }
    }
            
}
