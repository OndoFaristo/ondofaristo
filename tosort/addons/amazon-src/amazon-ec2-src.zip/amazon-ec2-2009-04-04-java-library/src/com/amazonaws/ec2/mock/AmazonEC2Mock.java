/******************************************************************************* 
 *  Copyright 2008 Amazon Technologies, Inc.
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  
 *  You may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at: http://aws.amazon.com/apache2.0
 *  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 *  specific language governing permissions and limitations under the License.
 * ***************************************************************************** 
 *    __  _    _  ___ 
 *   (  )( \/\/ )/ __)
 *   /__\ \    / \__ \
 *  (_)(_) \/\/  (___/
 * 
 *  Amazon EC2 Java Library
 *  API Version: 2009-04-04
 *  Generated: Sun May 17 14:47:07 PDT 2009 
 * 
 */



package com.amazonaws.ec2.mock;

import com.amazonaws.ec2.model.*;
import com.amazonaws.ec2.*;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Map;
import java.util.Map.Entry;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.InputSource;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

/**
 *
 * AmazonEC2Mock is the implementation of AmazonEC2 based
 * on the pre-populated set of XML files that serve local data. It simulates 
 * responses from Amazon EC2 service.
 *
 * Use this to test your application without making a call to Amazon EC2 
 *
 * Note, current Mock Service implementation does not valiadate requests
 *
 */
public  class AmazonEC2Mock implements AmazonEC2 {
    
    private final Log log = LogFactory.getLog(AmazonEC2Mock.class);
    private static JAXBContext  jaxbContext;
    private static ThreadLocal<Unmarshaller> unmarshaller;

    
    /** Initialize JAXBContext and  Unmarshaller **/
    static {
        try {
            jaxbContext = JAXBContext.newInstance("com.amazonaws.ec2.model", AmazonEC2.class.getClassLoader());
        } catch (JAXBException ex) {
            throw new ExceptionInInitializerError(ex);
        }
        unmarshaller = new ThreadLocal<Unmarshaller>() {
            protected synchronized Unmarshaller initialValue() {
                try {
                    return jaxbContext.createUnmarshaller();
                } catch(JAXBException e) {
                    throw new ExceptionInInitializerError(e);
                }
            }
        };
    }

    // Public API ------------------------------------------------------------//
    
        
    /**
     * Allocate Address 
     *
     * The AllocateAddress operation acquires an elastic IP address for use with your
     * account.
     *   
     * @param request
     *          AllocateAddress Action
     * @return
     *          AllocateAddress Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public AllocateAddressResponse allocateAddress(AllocateAddressRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("AllocateAddress");
        log.debug("Response transformed: " + transformedResponse);
        AllocateAddressResponse response;
        try {
            log.debug("Attempting to unmarshall into AllocateAddressResponse");
            response = (AllocateAddressResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Associate Address 
     *
     * The AssociateAddress operation associates an elastic IP address with an
     * instance.
     * If the IP address is currently assigned to another instance, the IP address is
     * assigned to the new instance. This is an idempotent operation. If you enter it
     * more than once, Amazon EC2 does not return an error.
     *   
     * @param request
     *          AssociateAddress Action
     * @return
     *          AssociateAddress Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public AssociateAddressResponse associateAddress(AssociateAddressRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("AssociateAddress");
        log.debug("Response transformed: " + transformedResponse);
        AssociateAddressResponse response;
        try {
            log.debug("Attempting to unmarshall into AssociateAddressResponse");
            response = (AssociateAddressResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Attach Volume 
     *
     * Attach a previously created volume to a running instance.
     *   
     * @param request
     *          AttachVolume Action
     * @return
     *          AttachVolume Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public AttachVolumeResponse attachVolume(AttachVolumeRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("AttachVolume");
        log.debug("Response transformed: " + transformedResponse);
        AttachVolumeResponse response;
        try {
            log.debug("Attempting to unmarshall into AttachVolumeResponse");
            response = (AttachVolumeResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Authorize Security Group Ingress 
     *
     * The AuthorizeSecurityGroupIngress operation adds permissions to a security
     * group.
     * Permissions are specified by the IP protocol (TCP, UDP or ICMP), the source of
     * the request (by IP range or an Amazon EC2 user-group pair), the source and
     * destination port ranges (for TCP and UDP), and the ICMP codes and types (for
     * ICMP). When authorizing ICMP, -1 can be used as a wildcard in the type and code
     * fields.
     * Permission changes are propagated to instances within the security group as
     * quickly as possible. However, depending on the number of instances, a small
     * delay might occur.
     * When authorizing a user/group pair permission, GroupName,
     * SourceSecurityGroupName and SourceSecurityGroupOwnerId must be specified. When
     * authorizing a CIDR IP permission, GroupName, IpProtocol, FromPort, ToPort and
     * CidrIp must be specified. Mixing these two types of parameters is not allowed.
     *   
     * @param request
     *          AuthorizeSecurityGroupIngress Action
     * @return
     *          AuthorizeSecurityGroupIngress Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public AuthorizeSecurityGroupIngressResponse authorizeSecurityGroupIngress(AuthorizeSecurityGroupIngressRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("AuthorizeSecurityGroupIngress");
        log.debug("Response transformed: " + transformedResponse);
        AuthorizeSecurityGroupIngressResponse response;
        try {
            log.debug("Attempting to unmarshall into AuthorizeSecurityGroupIngressResponse");
            response = (AuthorizeSecurityGroupIngressResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Bundle Instance 
     *
     * The BundleInstance operation request that an instance is bundled the next time it boots.
     * The bundling process creates a new image from a running instance and stores
     * the AMI data in S3. Once bundled, the image must be registered in the normal
     * way using the RegisterImage API.
     *   
     * @param request
     *          BundleInstance Action
     * @return
     *          BundleInstance Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public BundleInstanceResponse bundleInstance(BundleInstanceRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("BundleInstance");
        log.debug("Response transformed: " + transformedResponse);
        BundleInstanceResponse response;
        try {
            log.debug("Attempting to unmarshall into BundleInstanceResponse");
            response = (BundleInstanceResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Cancel Bundle Task 
     *
     * CancelBundleTask operation cancels a pending or
     * in-progress bundling task. This is an asynchronous
     * call and it make take a while for the task to be cancelled.
     * If a task is cancelled while it is storing items,
     * there may be parts of the incomplete AMI stored in S3.
     * It is up to the caller to clean up these parts from S3.
     *   
     * @param request
     *          CancelBundleTask Action
     * @return
     *          CancelBundleTask Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public CancelBundleTaskResponse cancelBundleTask(CancelBundleTaskRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("CancelBundleTask");
        log.debug("Response transformed: " + transformedResponse);
        CancelBundleTaskResponse response;
        try {
            log.debug("Attempting to unmarshall into CancelBundleTaskResponse");
            response = (CancelBundleTaskResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Confirm Product Instance 
     *
     * The ConfirmProductInstance operation returns true if the specified product code
     * is attached to the specified instance. The operation returns false if the
     * product code is not attached to the instance.
     * The ConfirmProductInstance operation can only be executed by the owner of the
     * AMI. This feature is useful when an AMI owner is providing support and wants to
     * verify whether a user's instance is eligible.
     *   
     * @param request
     *          ConfirmProductInstance Action
     * @return
     *          ConfirmProductInstance Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public ConfirmProductInstanceResponse confirmProductInstance(ConfirmProductInstanceRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("ConfirmProductInstance");
        log.debug("Response transformed: " + transformedResponse);
        ConfirmProductInstanceResponse response;
        try {
            log.debug("Attempting to unmarshall into ConfirmProductInstanceResponse");
            response = (ConfirmProductInstanceResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Create Key Pair 
     *
     * The CreateKeyPair operation creates a new 2048 bit RSA key pair and returns a
     * unique ID that can be used to reference this key pair when launching new
     * instances. For more information, see RunInstances.
     *   
     * @param request
     *          CreateKeyPair Action
     * @return
     *          CreateKeyPair Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public CreateKeyPairResponse createKeyPair(CreateKeyPairRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("CreateKeyPair");
        log.debug("Response transformed: " + transformedResponse);
        CreateKeyPairResponse response;
        try {
            log.debug("Attempting to unmarshall into CreateKeyPairResponse");
            response = (CreateKeyPairResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Create Security Group 
     *
     * The CreateSecurityGroup operation creates a new security group.
     * Every instance is launched in a security group. If no security group is
     * specified during launch, the instances are launched in the default security
     * group. Instances within the same security group have unrestricted network
     * access to each other. Instances will reject network access attempts from other
     * instances in a different security group. As the owner of instances you can
     * grant or revoke specific permissions using the AuthorizeSecurityGroupIngress
     * and RevokeSecurityGroupIngress operations.
     *   
     * @param request
     *          CreateSecurityGroup Action
     * @return
     *          CreateSecurityGroup Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public CreateSecurityGroupResponse createSecurityGroup(CreateSecurityGroupRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("CreateSecurityGroup");
        log.debug("Response transformed: " + transformedResponse);
        CreateSecurityGroupResponse response;
        try {
            log.debug("Attempting to unmarshall into CreateSecurityGroupResponse");
            response = (CreateSecurityGroupResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Create Snapshot 
     *
     * Create a snapshot of the volume identified by volume ID. A volume does not have to be detached
     * at the time the snapshot is taken.
     * Important Note:
     * Snapshot creation requires that the system is in a consistent state.
     * For instance, this means that if taking a snapshot of a database, the tables must
     * be read-only locked to ensure that the snapshot will not contain a corrupted
     * version of the database.  Therefore, be careful when using this API to ensure that
     * the system remains in the consistent state until the create snapshot status
     * has returned.
     *   
     * @param request
     *          CreateSnapshot Action
     * @return
     *          CreateSnapshot Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public CreateSnapshotResponse createSnapshot(CreateSnapshotRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("CreateSnapshot");
        log.debug("Response transformed: " + transformedResponse);
        CreateSnapshotResponse response;
        try {
            log.debug("Attempting to unmarshall into CreateSnapshotResponse");
            response = (CreateSnapshotResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Create Volume 
     *
     * Initializes an empty volume of a given size
     *   
     * @param request
     *          CreateVolume Action
     * @return
     *          CreateVolume Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public CreateVolumeResponse createVolume(CreateVolumeRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("CreateVolume");
        log.debug("Response transformed: " + transformedResponse);
        CreateVolumeResponse response;
        try {
            log.debug("Attempting to unmarshall into CreateVolumeResponse");
            response = (CreateVolumeResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Delete Key Pair 
     *
     * The DeleteKeyPair operation deletes a key pair.
     *   
     * @param request
     *          DeleteKeyPair Action
     * @return
     *          DeleteKeyPair Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DeleteKeyPairResponse deleteKeyPair(DeleteKeyPairRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DeleteKeyPair");
        log.debug("Response transformed: " + transformedResponse);
        DeleteKeyPairResponse response;
        try {
            log.debug("Attempting to unmarshall into DeleteKeyPairResponse");
            response = (DeleteKeyPairResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Delete Security Group 
     *
     * The DeleteSecurityGroup operation deletes a security group.
     * Note:
     * If you attempt to delete a security group that contains instances, a fault is
     * returned.
     * If you attempt to delete a security group that is referenced by another
     * security group, a fault is returned. For example, if security group B has a
     * rule that allows access from security group A, security group A cannot be
     * deleted until the allow rule is removed.
     *   
     * @param request
     *          DeleteSecurityGroup Action
     * @return
     *          DeleteSecurityGroup Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DeleteSecurityGroupResponse deleteSecurityGroup(DeleteSecurityGroupRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DeleteSecurityGroup");
        log.debug("Response transformed: " + transformedResponse);
        DeleteSecurityGroupResponse response;
        try {
            log.debug("Attempting to unmarshall into DeleteSecurityGroupResponse");
            response = (DeleteSecurityGroupResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Delete Snapshot 
     *
     * Deletes the snapshot identitied by snapshotId.
     *   
     * @param request
     *          DeleteSnapshot Action
     * @return
     *          DeleteSnapshot Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DeleteSnapshotResponse deleteSnapshot(DeleteSnapshotRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DeleteSnapshot");
        log.debug("Response transformed: " + transformedResponse);
        DeleteSnapshotResponse response;
        try {
            log.debug("Attempting to unmarshall into DeleteSnapshotResponse");
            response = (DeleteSnapshotResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Delete Volume 
     *
     * Deletes a  previously created volume. Once successfully deleted, a new volume  can be created with the same name.
     *   
     * @param request
     *          DeleteVolume Action
     * @return
     *          DeleteVolume Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DeleteVolumeResponse deleteVolume(DeleteVolumeRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DeleteVolume");
        log.debug("Response transformed: " + transformedResponse);
        DeleteVolumeResponse response;
        try {
            log.debug("Attempting to unmarshall into DeleteVolumeResponse");
            response = (DeleteVolumeResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Deregister Image 
     *
     * The DeregisterImage operation deregisters an AMI. Once deregistered, instances
     * of the AMI can no longer be launched.
     *   
     * @param request
     *          DeregisterImage Action
     * @return
     *          DeregisterImage Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DeregisterImageResponse deregisterImage(DeregisterImageRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DeregisterImage");
        log.debug("Response transformed: " + transformedResponse);
        DeregisterImageResponse response;
        try {
            log.debug("Attempting to unmarshall into DeregisterImageResponse");
            response = (DeregisterImageResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Describe Addresses 
     *
     * The DescribeAddresses operation lists elastic IP addresses assigned to your
     * account.
     *   
     * @param request
     *          DescribeAddresses Action
     * @return
     *          DescribeAddresses Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DescribeAddressesResponse describeAddresses(DescribeAddressesRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DescribeAddresses");
        log.debug("Response transformed: " + transformedResponse);
        DescribeAddressesResponse response;
        try {
            log.debug("Attempting to unmarshall into DescribeAddressesResponse");
            response = (DescribeAddressesResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Describe Availability Zones 
     *
     * The DescribeAvailabilityZones operation describes availability zones that are
     * currently available to the account and their states.
     * Availability zones are not the same across accounts. The availability zone
     * us-east-1a for account A is not necessarily the same as us-east-1a for account
     * B. Zone assignments are mapped independently for each account.
     *   
     * @param request
     *          DescribeAvailabilityZones Action
     * @return
     *          DescribeAvailabilityZones Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DescribeAvailabilityZonesResponse describeAvailabilityZones(DescribeAvailabilityZonesRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DescribeAvailabilityZones");
        log.debug("Response transformed: " + transformedResponse);
        DescribeAvailabilityZonesResponse response;
        try {
            log.debug("Attempting to unmarshall into DescribeAvailabilityZonesResponse");
            response = (DescribeAvailabilityZonesResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Describe Bundle Tasks 
     *
     * The DescribeBundleTasks operation describes in-progress
     * and recent bundle tasks. Complete and failed tasks are
     * removed from the list a short time after completion.
     * If no bundle ids are given, all bundle tasks are returned.
     *   
     * @param request
     *          DescribeBundleTasks Action
     * @return
     *          DescribeBundleTasks Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DescribeBundleTasksResponse describeBundleTasks(DescribeBundleTasksRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DescribeBundleTasks");
        log.debug("Response transformed: " + transformedResponse);
        DescribeBundleTasksResponse response;
        try {
            log.debug("Attempting to unmarshall into DescribeBundleTasksResponse");
            response = (DescribeBundleTasksResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Describe Image Attribute 
     *
     * The DescribeImageAttribute operation returns information about an attribute of
     * an AMI. Only one attribute can be specified per call.
     *   
     * @param request
     *          DescribeImageAttribute Action
     * @return
     *          DescribeImageAttribute Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DescribeImageAttributeResponse describeImageAttribute(DescribeImageAttributeRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DescribeImageAttribute");
        log.debug("Response transformed: " + transformedResponse);
        DescribeImageAttributeResponse response;
        try {
            log.debug("Attempting to unmarshall into DescribeImageAttributeResponse");
            response = (DescribeImageAttributeResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Describe Images 
     *
     * The DescribeImages operation returns information about AMIs, AKIs, and ARIs
     * available to the user. Information returned includes image type, product codes,
     * architecture, and kernel and RAM disk IDs. Images available to the user include
     * public images available for any user to launch, private images owned by the
     * user making the request, and private images owned by other users for which the
     * user has explicit launch permissions.
     * Launch permissions fall into three categories:
     * Public:
     * The owner of the AMI granted launch permissions for the AMI to the all group.
     * All users have launch permissions for these AMIs.
     * Explicit:
     * The owner of the AMI granted launch permissions to a specific user.
     * Implicit:
     * A user has implicit launch permissions for all AMIs he or she owns.
     * The list of AMIs returned can be modified by specifying AMI IDs, AMI owners, or
     * users with launch permissions. If no options are specified, Amazon EC2 returns
     * all AMIs for which the user has launch permissions.
     * If you specify one or more AMI IDs, only AMIs that have the specified IDs are
     * returned. If you specify an invalid AMI ID, a fault is returned. If you specify
     * an AMI ID for which you do not have access, it will not be included in the
     * returned results.
     * If you specify one or more AMI owners, only AMIs from the specified owners and
     * for which you have access are returned. The results can include the account IDs
     * of the specified owners, amazon for AMIs owned by Amazon or self for AMIs that
     * you own.
     * If you specify a list of executable users, only users that have launch
     * permissions for the AMIs are returned. You can specify account IDs (if you own
     * the AMI(s)), self for AMIs for which you own or have explicit permissions, or
     * all for public AMIs.
     * Note:
     * Deregistered images are included in the returned results for an unspecified
     * interval after deregistration.
     *   
     * @param request
     *          DescribeImages Action
     * @return
     *          DescribeImages Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DescribeImagesResponse describeImages(DescribeImagesRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DescribeImages");
        log.debug("Response transformed: " + transformedResponse);
        DescribeImagesResponse response;
        try {
            log.debug("Attempting to unmarshall into DescribeImagesResponse");
            response = (DescribeImagesResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Describe Instances 
     *
     * The DescribeInstances operation returns information about instances that you
     * own.
     * If you specify one or more instance IDs, Amazon EC2 returns information for
     * those instances. If you do not specify instance IDs, Amazon EC2 returns
     * information for all relevant instances. If you specify an invalid instance ID,
     * a fault is returned. If you specify an instance that you do not own, it will
     * not be included in the returned results.
     * Recently terminated instances might appear in the returned results. This
     * interval is usually less than one hour.
     *   
     * @param request
     *          DescribeInstances Action
     * @return
     *          DescribeInstances Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DescribeInstancesResponse describeInstances(DescribeInstancesRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DescribeInstances");
        log.debug("Response transformed: " + transformedResponse);
        DescribeInstancesResponse response;
        try {
            log.debug("Attempting to unmarshall into DescribeInstancesResponse");
            response = (DescribeInstancesResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Describe Regions 
     *
     * The DescribeRegions operation describes regions zones that are currently available to the account.
     *   
     * @param request
     *          DescribeRegions Action
     * @return
     *          DescribeRegions Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DescribeRegionsResponse describeRegions(DescribeRegionsRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DescribeRegions");
        log.debug("Response transformed: " + transformedResponse);
        DescribeRegionsResponse response;
        try {
            log.debug("Attempting to unmarshall into DescribeRegionsResponse");
            response = (DescribeRegionsResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Describe Reserved Instances 
     *
     * The DescribeReservedInstances operation describes Reserved Instances that were purchased for use with your account.
     *   
     * @param request
     *          DescribeReservedInstances Action
     * @return
     *          DescribeReservedInstances Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DescribeReservedInstancesResponse describeReservedInstances(DescribeReservedInstancesRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DescribeReservedInstances");
        log.debug("Response transformed: " + transformedResponse);
        DescribeReservedInstancesResponse response;
        try {
            log.debug("Attempting to unmarshall into DescribeReservedInstancesResponse");
            response = (DescribeReservedInstancesResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Describe Reserved Instances Offerings 
     *
     * The DescribeReservedInstancesOfferings operation describes Reserved
     * Instance offerings that are available for purchase. With Amazon EC2
     * Reserved Instances, you purchase the right to launch Amazon EC2 instances
     * for a period of time (without getting insufficient capacity errors) and
     * pay a lower usage rate for the actual time used.
     *   
     * @param request
     *          DescribeReservedInstancesOfferings Action
     * @return
     *          DescribeReservedInstancesOfferings Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DescribeReservedInstancesOfferingsResponse describeReservedInstancesOfferings(DescribeReservedInstancesOfferingsRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DescribeReservedInstancesOfferings");
        log.debug("Response transformed: " + transformedResponse);
        DescribeReservedInstancesOfferingsResponse response;
        try {
            log.debug("Attempting to unmarshall into DescribeReservedInstancesOfferingsResponse");
            response = (DescribeReservedInstancesOfferingsResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Describe Key Pairs 
     *
     * The DescribeKeyPairs operation returns information about key pairs available to
     * you. If you specify key pairs, information about those key pairs is returned.
     * Otherwise, information for all registered key pairs is returned.
     *   
     * @param request
     *          DescribeKeyPairs Action
     * @return
     *          DescribeKeyPairs Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DescribeKeyPairsResponse describeKeyPairs(DescribeKeyPairsRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DescribeKeyPairs");
        log.debug("Response transformed: " + transformedResponse);
        DescribeKeyPairsResponse response;
        try {
            log.debug("Attempting to unmarshall into DescribeKeyPairsResponse");
            response = (DescribeKeyPairsResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Describe Security Groups 
     *
     * The DescribeSecurityGroups operation returns information about security groups
     * that you own.
     * If you specify security group names, information about those security group is
     * returned. Otherwise, information for all security group is returned. If you
     * specify a group that does not exist, a fault is returned.
     *   
     * @param request
     *          DescribeSecurityGroups Action
     * @return
     *          DescribeSecurityGroups Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DescribeSecurityGroupsResponse describeSecurityGroups(DescribeSecurityGroupsRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DescribeSecurityGroups");
        log.debug("Response transformed: " + transformedResponse);
        DescribeSecurityGroupsResponse response;
        try {
            log.debug("Attempting to unmarshall into DescribeSecurityGroupsResponse");
            response = (DescribeSecurityGroupsResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Describe Snapshots 
     *
     * Describes the indicated snapshots, or in lieu of that, all snapshots owned by the caller.
     *   
     * @param request
     *          DescribeSnapshots Action
     * @return
     *          DescribeSnapshots Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DescribeSnapshotsResponse describeSnapshots(DescribeSnapshotsRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DescribeSnapshots");
        log.debug("Response transformed: " + transformedResponse);
        DescribeSnapshotsResponse response;
        try {
            log.debug("Attempting to unmarshall into DescribeSnapshotsResponse");
            response = (DescribeSnapshotsResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Describe Volumes 
     *
     * Describes the status of the indicated or, in lieu of any specified,  all volumes belonging to the caller. Volumes that have been deleted are not described.
     *   
     * @param request
     *          DescribeVolumes Action
     * @return
     *          DescribeVolumes Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DescribeVolumesResponse describeVolumes(DescribeVolumesRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DescribeVolumes");
        log.debug("Response transformed: " + transformedResponse);
        DescribeVolumesResponse response;
        try {
            log.debug("Attempting to unmarshall into DescribeVolumesResponse");
            response = (DescribeVolumesResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Detach Volume 
     *
     * Detach a previously attached volume from a running instance.
     *   
     * @param request
     *          DetachVolume Action
     * @return
     *          DetachVolume Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DetachVolumeResponse detachVolume(DetachVolumeRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DetachVolume");
        log.debug("Response transformed: " + transformedResponse);
        DetachVolumeResponse response;
        try {
            log.debug("Attempting to unmarshall into DetachVolumeResponse");
            response = (DetachVolumeResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Disassociate Address 
     *
     * The DisassociateAddress operation disassociates the specified elastic IP
     * address from the instance to which it is assigned. This is an idempotent
     * operation. If you enter it more than once, Amazon EC2 does not return an error.
     *   
     * @param request
     *          DisassociateAddress Action
     * @return
     *          DisassociateAddress Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public DisassociateAddressResponse disassociateAddress(DisassociateAddressRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("DisassociateAddress");
        log.debug("Response transformed: " + transformedResponse);
        DisassociateAddressResponse response;
        try {
            log.debug("Attempting to unmarshall into DisassociateAddressResponse");
            response = (DisassociateAddressResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Get Console Output 
     *
     * The GetConsoleOutput operation retrieves console output for the specified
     * instance.
     * Instance console output is buffered and posted shortly after instance boot,
     * reboot, and termination. Amazon EC2 preserves the most recent 64 KB output
     * which will be available for at least one hour after the most recent post.
     *   
     * @param request
     *          GetConsoleOutput Action
     * @return
     *          GetConsoleOutput Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public GetConsoleOutputResponse getConsoleOutput(GetConsoleOutputRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("GetConsoleOutput");
        log.debug("Response transformed: " + transformedResponse);
        GetConsoleOutputResponse response;
        try {
            log.debug("Attempting to unmarshall into GetConsoleOutputResponse");
            response = (GetConsoleOutputResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Modify Image Attribute 
     *
     * The ModifyImageAttribute operation modifies an attribute of an AMI.
     *   
     * @param request
     *          ModifyImageAttribute Action
     * @return
     *          ModifyImageAttribute Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public ModifyImageAttributeResponse modifyImageAttribute(ModifyImageAttributeRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("ModifyImageAttribute");
        log.debug("Response transformed: " + transformedResponse);
        ModifyImageAttributeResponse response;
        try {
            log.debug("Attempting to unmarshall into ModifyImageAttributeResponse");
            response = (ModifyImageAttributeResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Purchase Reserved Instances Offering 
     *
     * The PurchaseReservedInstancesOffering operation purchases a
     * Reserved Instance for use with your account. With Amazon EC2
     * Reserved Instances, you purchase the right to launch Amazon EC2
     * instances for a period of time (without getting insufficient
     * capacity errors) and pay a lower usage rate for the
     * actual time used.
     *   
     * @param request
     *          PurchaseReservedInstancesOffering Action
     * @return
     *          PurchaseReservedInstancesOffering Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public PurchaseReservedInstancesOfferingResponse purchaseReservedInstancesOffering(PurchaseReservedInstancesOfferingRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("PurchaseReservedInstancesOffering");
        log.debug("Response transformed: " + transformedResponse);
        PurchaseReservedInstancesOfferingResponse response;
        try {
            log.debug("Attempting to unmarshall into PurchaseReservedInstancesOfferingResponse");
            response = (PurchaseReservedInstancesOfferingResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Reboot Instances 
     *
     * The RebootInstances operation requests a reboot of one or more instances. This
     * operation is asynchronous; it only queues a request to reboot the specified
     * instance(s). The operation will succeed if the instances are valid and belong
     * to the user. Requests to reboot terminated instances are ignored.
     *   
     * @param request
     *          RebootInstances Action
     * @return
     *          RebootInstances Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public RebootInstancesResponse rebootInstances(RebootInstancesRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("RebootInstances");
        log.debug("Response transformed: " + transformedResponse);
        RebootInstancesResponse response;
        try {
            log.debug("Attempting to unmarshall into RebootInstancesResponse");
            response = (RebootInstancesResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Register Image 
     *
     * The RegisterImage operation registers an AMI with Amazon EC2. Images must be
     * registered before they can be launched. For more information, see RunInstances.
     * Each AMI is associated with an unique ID which is provided by the Amazon EC2
     * service through the RegisterImage operation. During registration, Amazon EC2
     * retrieves the specified image manifest from Amazon S3 and verifies that the
     * image is owned by the user registering the image.
     * The image manifest is retrieved once and stored within the Amazon EC2. Any
     * modifications to an image in Amazon S3 invalidates this registration. If you
     * make changes to an image, deregister the previous image and register the new
     * image. For more information, see DeregisterImage.
     *   
     * @param request
     *          RegisterImage Action
     * @return
     *          RegisterImage Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public RegisterImageResponse registerImage(RegisterImageRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("RegisterImage");
        log.debug("Response transformed: " + transformedResponse);
        RegisterImageResponse response;
        try {
            log.debug("Attempting to unmarshall into RegisterImageResponse");
            response = (RegisterImageResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Release Address 
     *
     * The ReleaseAddress operation releases an elastic IP address associated with
     * your account.
     * Note:
     * Releasing an IP address automatically disassociates it from any instance with
     * which it is associated. For more information, see DisassociateAddress.
     * Important:
     * After releasing an elastic IP address, it is released to the IP address pool
     * and might no longer be available to your account. Make sure to update your DNS
     * records and any servers or devices that communicate with the address.
     * If you run this operation on an elastic IP address that is already released,
     * the address might be assigned to another account which will cause Amazon EC2 to
     * return an error.
     *   
     * @param request
     *          ReleaseAddress Action
     * @return
     *          ReleaseAddress Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public ReleaseAddressResponse releaseAddress(ReleaseAddressRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("ReleaseAddress");
        log.debug("Response transformed: " + transformedResponse);
        ReleaseAddressResponse response;
        try {
            log.debug("Attempting to unmarshall into ReleaseAddressResponse");
            response = (ReleaseAddressResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Reset Image Attribute 
     *
     * The ResetImageAttribute operation resets an attribute of an AMI to its default
     * value.
     * Note:
     * The productCodes attribute cannot be reset.
     *   
     * @param request
     *          ResetImageAttribute Action
     * @return
     *          ResetImageAttribute Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public ResetImageAttributeResponse resetImageAttribute(ResetImageAttributeRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("ResetImageAttribute");
        log.debug("Response transformed: " + transformedResponse);
        ResetImageAttributeResponse response;
        try {
            log.debug("Attempting to unmarshall into ResetImageAttributeResponse");
            response = (ResetImageAttributeResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Revoke Security Group Ingress 
     *
     * The RevokeSecurityGroupIngress operation revokes permissions from a security
     * group. The permissions used to revoke must be specified using the same values
     * used to grant the permissions.
     * Permissions are specified by IP protocol (TCP, UDP, or ICMP), the source of the
     * request (by IP range or an Amazon EC2 user-group pair), the source and
     * destination port ranges (for TCP and UDP), and the ICMP codes and types (for
     * ICMP).
     * Permission changes are quickly propagated to instances within the security
     * group. However, depending on the number of instances in the group, a small
     * delay is might occur, .
     * When revoking a user/group pair permission, GroupName, SourceSecurityGroupName
     * and SourceSecurityGroupOwnerId must be specified. When authorizing a CIDR IP
     * permission, GroupName, IpProtocol, FromPort, ToPort and CidrIp must be
     * specified. Mixing these two types of parameters is not allowed.
     *   
     * @param request
     *          RevokeSecurityGroupIngress Action
     * @return
     *          RevokeSecurityGroupIngress Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public RevokeSecurityGroupIngressResponse revokeSecurityGroupIngress(RevokeSecurityGroupIngressRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("RevokeSecurityGroupIngress");
        log.debug("Response transformed: " + transformedResponse);
        RevokeSecurityGroupIngressResponse response;
        try {
            log.debug("Attempting to unmarshall into RevokeSecurityGroupIngressResponse");
            response = (RevokeSecurityGroupIngressResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Run Instances 
     *
     * The RunInstances operation launches a specified number of instances.
     * If Amazon EC2 cannot launch the minimum number AMIs you request, no instances
     * launch. If there is insufficient capacity to launch the maximum number of AMIs
     * you request, Amazon EC2 launches as many as possible to satisfy the requested
     * maximum values.
     * Every instance is launched in a security group. If you do not specify a
     * security group at launch, the instances start in your default security group.
     * For more information on creating security groups, see CreateSecurityGroup.
     * An optional instance type can be specified. For information about instance
     * types, see Instance Types.
     * You can provide an optional key pair ID for each image in the launch request
     * (for more information, see CreateKeyPair). All instances that are created from
     * images that use this key pair will have access to the associated public key at
     * boot. You can use this key to provide secure access to an instance of an image
     * on a per-instance basis. Amazon EC2 public images use this feature to provide
     * secure access without passwords.
     * Important:
     * Launching public images without a key pair ID will leave them inaccessible.
     * The public key material is made available to the instance at boot time by
     * placing it in the openssh_id.pub file on a logical device that is exposed to
     * the instance as /dev/sda2 (the ephemeral store). The format of this file is
     * suitable for use as an entry within ~/.ssh/authorized_keys (the OpenSSH
     * format). This can be done at boot (e.g., as part of rc.local) allowing for
     * secure access without passwords.
     * Optional user data can be provided in the launch request. All instances that
     * collectively comprise the launch request have access to this data For more
     * information, see Instance Metadata.
     * Note:
     * If any of the AMIs have a product code attached for which the user has not
     * subscribed, the RunInstances call will fail.
     * Important:
     * We strongly recommend using the 2.6.18 Xen stock kernel with the c1.medium and
     * c1.xlarge instances. Although the default Amazon EC2 kernels will work, the new
     * kernels provide greater stability and performance for these instance types. For
     * more information about kernels, see Kernels, RAM Disks, and Block Device
     * Mappings.
     *   
     * @param request
     *          RunInstances Action
     * @return
     *          RunInstances Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public RunInstancesResponse runInstances(RunInstancesRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("RunInstances");
        log.debug("Response transformed: " + transformedResponse);
        RunInstancesResponse response;
        try {
            log.debug("Attempting to unmarshall into RunInstancesResponse");
            response = (RunInstancesResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Terminate Instances 
     *
     * The TerminateInstances operation shuts down one or more instances. This
     * operation is idempotent; if you terminate an instance more than once, each call
     * will succeed.
     * Terminated instances will remain visible after termination (approximately one
     * hour).
     *   
     * @param request
     *          TerminateInstances Action
     * @return
     *          TerminateInstances Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public TerminateInstancesResponse terminateInstances(TerminateInstancesRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("TerminateInstances");
        log.debug("Response transformed: " + transformedResponse);
        TerminateInstancesResponse response;
        try {
            log.debug("Attempting to unmarshall into TerminateInstancesResponse");
            response = (TerminateInstancesResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Monitor Instances 
     *
     * Enables monitoring for a running instance.
     *   
     * @param request
     *          MonitorInstances Action
     * @return
     *          MonitorInstances Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public MonitorInstancesResponse monitorInstances(MonitorInstancesRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("MonitorInstances");
        log.debug("Response transformed: " + transformedResponse);
        MonitorInstancesResponse response;
        try {
            log.debug("Attempting to unmarshall into MonitorInstancesResponse");
            response = (MonitorInstancesResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }

        
    /**
     * Unmonitor Instances 
     *
     * Disables monitoring for a running instance.
     *   
     * @param request
     *          UnmonitorInstances Action
     * @return
     *          UnmonitorInstances Response from the service
     *
     * @throws AmazonEC2Exception
     */
    public UnmonitorInstancesResponse unmonitorInstances(UnmonitorInstancesRequest request)
        throws AmazonEC2Exception {
        String transformedResponse = ResponseTransformer.transform("UnmonitorInstances");
        log.debug("Response transformed: " + transformedResponse);
        UnmonitorInstancesResponse response;
        try {
            log.debug("Attempting to unmarshall into UnmonitorInstancesResponse");
            response = (UnmonitorInstancesResponse) getUnmarshaller().unmarshal
                    (new StreamSource(new StringReader(transformedResponse)));
            log.debug("Response from Mock Service: " + response.toXML());
        } catch (JAXBException jbe) {
            throw new AmazonEC2Exception("Unable to process mock response", jbe);
        }
        return response;
    }


    /**
     * Get unmarshaller for current thread
     */
    private Unmarshaller getUnmarshaller() {
        return unmarshaller.get();
    }

    private static class ResponseTransformer {

        /**
         * Transforms XML with XSLT into string.
         * @param response XML resource
         * @param actionName action name to perform the transformation on
         * @return transformed string
         */
        private static String transform(String actionName) {
            InputSource responseXML = new InputSource(AmazonEC2.class
              .getClassLoader().getResourceAsStream("com/amazonaws/ec2/mock/"
              + actionName + "Response.xml"));
            InputSource responseXSLT = new InputSource(AmazonEC2.class
              .getClassLoader().getResourceAsStream("com/amazonaws/ec2/model/"
               + actionName + "Response.xslt"));
            return transform(fromStream(responseXML),
                    fromStream(responseXSLT), null);
        }

        /**
         * Transforms XML with XSLT into string.
         * @param xml source document
         * @param xslt source template
         * @param parameters map of parameters to pass to XSLT for transformation
         * @return transformed string
         */
        private static String transform(Source xml, Source xslt, Map<String, String> parameters) {
            try {
                Transformer transformer = TransformerFactory.newInstance().newTransformer(xslt);
                StringWriter output = new StringWriter();
                if (parameters != null) {
                    for (Entry<String, String> entry : parameters.entrySet()) {
                        transformer.setParameter(entry.getKey(), entry.getValue());
                    }
                }
                transformer.transform(xml, new StreamResult(output));
                return output.toString();
            } catch (Exception ex) {
                throw new RuntimeException("XSLT transformation failed", ex);
            }
        }

        private static Source fromStream(InputSource source) {
            return new StreamSource(source.getByteStream());
        }
    }
}