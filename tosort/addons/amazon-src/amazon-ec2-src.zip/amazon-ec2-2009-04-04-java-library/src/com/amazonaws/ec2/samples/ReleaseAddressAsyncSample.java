/******************************************************************************* 
 *  Copyright 2008 Amazon Technologies, Inc.
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  
 *  You may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at: http://aws.amazon.com/apache2.0
 *  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 *  specific language governing permissions and limitations under the License.
 * ***************************************************************************** 
 *    __  _    _  ___ 
 *   (  )( \/\/ )/ __)
 *   /__\ \    / \__ \
 *  (_)(_) \/\/  (___/
 * 
 *  Amazon EC2 Java Library
 *  API Version: 2009-04-04
 *  Generated: Sun May 17 14:47:07 PDT 2009 
 * 
 */



package com.amazonaws.ec2.samples;

import java.util.List;
import java.util.ArrayList;
import com.amazonaws.ec2.*;
import com.amazonaws.ec2.model.*;
import java.util.concurrent.Future;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

/**
 *
 * Release Address  Samples
 *
 *
 */
public class ReleaseAddressAsyncSample {

    /**
     * Just add few required parameters, and try the service
     * Release Address functionality
     *
     * @param args unused
     */
    public static void main(String... args) {
        
        /************************************************************************
         * Access Key ID and Secret Acess Key ID, obtained from:
         * http://aws.amazon.com
         ***********************************************************************/
         String accessKeyId = "<Your Access Key ID>";
         String secretAccessKey = "<Your Secret Access Key>";

        /************************************************************************
         * Instantiate Http Client Implementation of Amazon EC2 
         * 
         * Important! Number of threads in executor should match number of connections
         * for http client.
         *
         ***********************************************************************/

         AmazonEC2Config config = new AmazonEC2Config().withMaxConnections (100);
         ExecutorService executor = Executors.newFixedThreadPool(100);
         AmazonEC2Async service = new AmazonEC2AsyncClient(accessKeyId, secretAccessKey, config, executor);

        /************************************************************************
         * Setup requests parameters and invoke parallel processing. Of course
         * in real world application, there will be much more than a couple of
         * requests to process.
         ***********************************************************************/
         ReleaseAddressRequest requestOne = new ReleaseAddressRequest();
         // @TODO: set request parameters here

         ReleaseAddressRequest requestTwo = new ReleaseAddressRequest();
         // @TODO: set second request parameters here

         List<ReleaseAddressRequest> requests = new ArrayList<ReleaseAddressRequest>();
         requests.add(requestOne);
         requests.add(requestTwo);

         invokeReleaseAddress(service, requests);

         executor.shutdown();

    }


                                                                                                                                                                        
    /**
     * Release Address request sample
     * The ReleaseAddress operation releases an elastic IP address associated with
     * your account.
     * Note:
     * Releasing an IP address automatically disassociates it from any instance with
     * which it is associated. For more information, see DisassociateAddress.
     * Important:
     * After releasing an elastic IP address, it is released to the IP address pool
     * and might no longer be available to your account. Make sure to update your DNS
     * records and any servers or devices that communicate with the address.
     * If you run this operation on an elastic IP address that is already released,
     * the address might be assigned to another account which will cause Amazon EC2 to
     * return an error.
     *   
     * @param service instance of AmazonEC2 service
     * @param requests list of requests to process
     */
    public static void invokeReleaseAddress(AmazonEC2Async service, List<ReleaseAddressRequest> requests) {
        List<Future<ReleaseAddressResponse>> responses = new ArrayList<Future<ReleaseAddressResponse>>();
        for (ReleaseAddressRequest request : requests) {
            responses.add(service.releaseAddressAsync(request));
        }
        for (Future<ReleaseAddressResponse> future : responses) {
            while (!future.isDone()) {
                Thread.yield();
            }
            try {
                ReleaseAddressResponse response = future.get();
                // Original request corresponding to this response, if needed:
                ReleaseAddressRequest originalRequest = requests.get(responses.indexOf(future));
                System.out.println("Response request id: " + response.getResponseMetadata().getRequestId());
            } catch (Exception e) {
                if (e.getCause() instanceof AmazonEC2Exception) {
                    AmazonEC2Exception exception = AmazonEC2Exception.class.cast(e.getCause());
                    System.out.println("Caught Exception: " + exception.getMessage());
                    System.out.println("Response Status Code: " + exception.getStatusCode());
                    System.out.println("Error Code: " + exception.getErrorCode());
                    System.out.println("Error Type: " + exception.getErrorType());
                    System.out.println("Request ID: " + exception.getRequestId());
                    System.out.print("XML: " + exception.getXML());
                } else {
                    e.printStackTrace();
                }
            }
        }
    }
                            
}
