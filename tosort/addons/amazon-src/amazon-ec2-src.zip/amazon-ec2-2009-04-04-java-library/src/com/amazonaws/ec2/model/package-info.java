@javax.xml.bind.annotation.XmlSchema(namespace = "http://ec2.amazonaws.com/doc/2009-04-04/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.amazonaws.ec2.model;
