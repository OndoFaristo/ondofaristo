/******************************************************************************* 
 *  Copyright 2008 Amazon Technologies, Inc.
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  
 *  You may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at: http://aws.amazon.com/apache2.0
 *  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 *  specific language governing permissions and limitations under the License.
 * ***************************************************************************** 
 *    __  _    _  ___ 
 *   (  )( \/\/ )/ __)
 *   /__\ \    / \__ \
 *  (_)(_) \/\/  (___/
 * 
 *  Amazon EC2 Java Library
 *  API Version: 2009-04-04
 *  Generated: Sun May 17 14:47:07 PDT 2009 
 * 
 */



package com.amazonaws.ec2.samples;

import java.util.List;
import java.util.ArrayList;
import com.amazonaws.ec2.*;
import com.amazonaws.ec2.model.*;
import com.amazonaws.ec2.mock.AmazonEC2Mock;

/**
 *
 * Describe Instances  Samples
 *
 *
 */
public class DescribeInstancesSample {

    /**
     * Just add few required parameters, and try the service
     * Describe Instances functionality
     *
     * @param args unused
     */
    public static void main(String... args) {
        
        /************************************************************************
         * Access Key ID and Secret Acess Key ID, obtained from:
         * http://aws.amazon.com
         ***********************************************************************/
        String accessKeyId = "<Your Access Key ID>";
        String secretAccessKey = "<Your Secret Access Key>";

        /************************************************************************
         * Instantiate Http Client Implementation of Amazon EC2 
         ***********************************************************************/
        AmazonEC2 service = new AmazonEC2Client(accessKeyId, secretAccessKey);
        
        /************************************************************************
         * Uncomment to try advanced configuration options. Available options are:
         *
         *  - Signature Version
         *  - Proxy Host and Proxy Port
         *  - Service URL
         *  - User Agent String to be sent to Amazon EC2   service
         *
         ***********************************************************************/
        // AmazonEC2Config config = new AmazonEC2Config();
        // config.setSignatureVersion("0");
        // AmazonEC2 service = new AmazonEC2Client(accessKeyId, secretAccessKey, config);
 
        /************************************************************************
         * Uncomment to try out Mock Service that simulates Amazon EC2 
         * responses without calling Amazon EC2  service.
         *
         * Responses are loaded from local XML files. You can tweak XML files to
         * experiment with various outputs during development
         *
         * XML files available under com/amazonaws/ec2/mock tree
         *
         ***********************************************************************/
        // AmazonEC2 service = new AmazonEC2Mock();

        /************************************************************************
         * Setup request parameters and uncomment invoke to try out 
         * sample for Describe Instances 
         ***********************************************************************/
         DescribeInstancesRequest request = new DescribeInstancesRequest();
        
         // @TODO: set request parameters here

         // invokeDescribeInstances(service, request);

    }


                                                                                                            
    /**
     * Describe Instances  request sample
     * The DescribeInstances operation returns information about instances that you
     * own.
     * If you specify one or more instance IDs, Amazon EC2 returns information for
     * those instances. If you do not specify instance IDs, Amazon EC2 returns
     * information for all relevant instances. If you specify an invalid instance ID,
     * a fault is returned. If you specify an instance that you do not own, it will
     * not be included in the returned results.
     * Recently terminated instances might appear in the returned results. This
     * interval is usually less than one hour.
     *   
     * @param service instance of AmazonEC2 service
     * @param request Action to invoke
     */
    public static void invokeDescribeInstances(AmazonEC2 service, DescribeInstancesRequest request) {
        try {
            
            DescribeInstancesResponse response = service.describeInstances(request);

            
            System.out.println ("DescribeInstances Action Response");
            System.out.println ("=============================================================================");
            System.out.println ();

            System.out.println("    DescribeInstancesResponse");
            System.out.println();
            if (response.isSetResponseMetadata()) {
                System.out.println("        ResponseMetadata");
                System.out.println();
                ResponseMetadata  responseMetadata = response.getResponseMetadata();
                if (responseMetadata.isSetRequestId()) {
                    System.out.println("            RequestId");
                    System.out.println();
                    System.out.println("                " + responseMetadata.getRequestId());
                    System.out.println();
                }
            } 
            if (response.isSetDescribeInstancesResult()) {
                System.out.println("        DescribeInstancesResult");
                System.out.println();
                DescribeInstancesResult  describeInstancesResult = response.getDescribeInstancesResult();
                java.util.List<Reservation> reservationList = describeInstancesResult.getReservation();
                for (Reservation reservation : reservationList) {
                    System.out.println("            Reservation");
                    System.out.println();
                    if (reservation.isSetReservationId()) {
                        System.out.println("                ReservationId");
                        System.out.println();
                        System.out.println("                    " + reservation.getReservationId());
                        System.out.println();
                    }
                    if (reservation.isSetOwnerId()) {
                        System.out.println("                OwnerId");
                        System.out.println();
                        System.out.println("                    " + reservation.getOwnerId());
                        System.out.println();
                    }
                    if (reservation.isSetRequesterId()) {
                        System.out.println("                RequesterId");
                        System.out.println();
                        System.out.println("                    " + reservation.getRequesterId());
                        System.out.println();
                    }
                    java.util.List<String> groupNameList  =  reservation.getGroupName();
                    for (String groupName : groupNameList) { 
                        System.out.println("                GroupName");
                            System.out.println();
                        System.out.println("                    " + groupName);
                    }	
                    java.util.List<RunningInstance> runningInstanceList = reservation.getRunningInstance();
                    for (RunningInstance runningInstance : runningInstanceList) {
                        System.out.println("                RunningInstance");
                        System.out.println();
                        if (runningInstance.isSetInstanceId()) {
                            System.out.println("                    InstanceId");
                            System.out.println();
                            System.out.println("                        " + runningInstance.getInstanceId());
                            System.out.println();
                        }
                        if (runningInstance.isSetImageId()) {
                            System.out.println("                    ImageId");
                            System.out.println();
                            System.out.println("                        " + runningInstance.getImageId());
                            System.out.println();
                        }
                        if (runningInstance.isSetInstanceState()) {
                            System.out.println("                    InstanceState");
                            System.out.println();
                            InstanceState  instanceState = runningInstance.getInstanceState();
                            if (instanceState.isSetCode()) {
                                System.out.println("                        Code");
                                System.out.println();
                                System.out.println("                            " + instanceState.getCode());
                                System.out.println();
                            }
                            if (instanceState.isSetName()) {
                                System.out.println("                        Name");
                                System.out.println();
                                System.out.println("                            " + instanceState.getName());
                                System.out.println();
                            }
                        } 
                        if (runningInstance.isSetPrivateDnsName()) {
                            System.out.println("                    PrivateDnsName");
                            System.out.println();
                            System.out.println("                        " + runningInstance.getPrivateDnsName());
                            System.out.println();
                        }
                        if (runningInstance.isSetPublicDnsName()) {
                            System.out.println("                    PublicDnsName");
                            System.out.println();
                            System.out.println("                        " + runningInstance.getPublicDnsName());
                            System.out.println();
                        }
                        if (runningInstance.isSetStateTransitionReason()) {
                            System.out.println("                    StateTransitionReason");
                            System.out.println();
                            System.out.println("                        " + runningInstance.getStateTransitionReason());
                            System.out.println();
                        }
                        if (runningInstance.isSetKeyName()) {
                            System.out.println("                    KeyName");
                            System.out.println();
                            System.out.println("                        " + runningInstance.getKeyName());
                            System.out.println();
                        }
                        if (runningInstance.isSetAmiLaunchIndex()) {
                            System.out.println("                    AmiLaunchIndex");
                            System.out.println();
                            System.out.println("                        " + runningInstance.getAmiLaunchIndex());
                            System.out.println();
                        }
                        java.util.List<String> productCodeList  =  runningInstance.getProductCode();
                        for (String productCode : productCodeList) { 
                            System.out.println("                    ProductCode");
                                System.out.println();
                            System.out.println("                        " + productCode);
                        }	
                        if (runningInstance.isSetInstanceType()) {
                            System.out.println("                    InstanceType");
                            System.out.println();
                            System.out.println("                        " + runningInstance.getInstanceType());
                            System.out.println();
                        }
                        if (runningInstance.isSetLaunchTime()) {
                            System.out.println("                    LaunchTime");
                            System.out.println();
                            System.out.println("                        " + runningInstance.getLaunchTime());
                            System.out.println();
                        }
                        if (runningInstance.isSetPlacement()) {
                            System.out.println("                    Placement");
                            System.out.println();
                            Placement  placement = runningInstance.getPlacement();
                            if (placement.isSetAvailabilityZone()) {
                                System.out.println("                        AvailabilityZone");
                                System.out.println();
                                System.out.println("                            " + placement.getAvailabilityZone());
                                System.out.println();
                            }
                        } 
                        if (runningInstance.isSetKernelId()) {
                            System.out.println("                    KernelId");
                            System.out.println();
                            System.out.println("                        " + runningInstance.getKernelId());
                            System.out.println();
                        }
                        if (runningInstance.isSetRamdiskId()) {
                            System.out.println("                    RamdiskId");
                            System.out.println();
                            System.out.println("                        " + runningInstance.getRamdiskId());
                            System.out.println();
                        }
                        if (runningInstance.isSetPlatform()) {
                            System.out.println("                    Platform");
                            System.out.println();
                            System.out.println("                        " + runningInstance.getPlatform());
                            System.out.println();
                        }
                        if (runningInstance.isSetMonitoring()) {
                            System.out.println("                    Monitoring");
                            System.out.println();
                            Monitoring  monitoring = runningInstance.getMonitoring();
                            if (monitoring.isSetMonitoringState()) {
                                System.out.println("                        MonitoringState");
                                System.out.println();
                                System.out.println("                            " + monitoring.getMonitoringState());
                                System.out.println();
                            }
                        } 
                    }
                }
            } 
            System.out.println();

           
        } catch (AmazonEC2Exception ex) {
            
            System.out.println("Caught Exception: " + ex.getMessage());
            System.out.println("Response Status Code: " + ex.getStatusCode());
            System.out.println("Error Code: " + ex.getErrorCode());
            System.out.println("Error Type: " + ex.getErrorType());
            System.out.println("Request ID: " + ex.getRequestId());
            System.out.print("XML: " + ex.getXML());
        }
    }
                                                                                        
}
